import requests
from bs4 import BeautifulSoup
import pandas as pd

url = "https://pkc.aero/schedule/"
response = requests.get(url)
soup = BeautifulSoup(response.text, 'html.parser')

table = soup.find('table')
rows = table.find_all('tr')

flights = []
for row in rows[1:]:
    cols = row.find_all('td')
    if len(cols) == 8:
        flight = {
            "Отправление": cols[0].text.strip(),
            "Прибытие": cols[1].text.strip(),
            "Дни полетов": cols[2].text.strip(),
            "Период": cols[3].text.strip(),
            "Авиакомпания": cols[4].text.strip(),
            "Номер рейса": cols[5].text.strip(),
            "Тип судна": cols[6].text.strip(),
            "Аэропорт": cols[7].text.strip()
        }
        flights.append(flight)

# Сохранение в CSV
df = pd.DataFrame(flights)
df.to_csv('flights_schedule.csv', index=False, encoding='utf-8-sig')

print(f"Сохранено {len(flights)} записей в flights_schedule.csv")