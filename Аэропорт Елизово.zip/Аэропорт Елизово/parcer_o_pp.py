import time
import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime

# Увеличиваем таймауты
REQUEST_TIMEOUT = 60  # 60 секунд на запрос
DELAY_BETWEEN_REQUESTS = 10  # 10 секунд между запросами

def get_wayback_snapshots(base_url, start_year, end_year):
    """Получает список доступных снапшотов с Wayback Machine"""
    wayback_api = "https://web.archive.org/cdx/search/cdx"
    params = {
        'url': base_url,
        'from': f"{start_year}0101",
        'to': f"{end_year}1231",
        'output': 'json',
        'collapse': 'timestamp:6',
        'filter': 'statuscode:200',
        'limit': 10000
    }
    
    try:
        response = requests.get(wayback_api, params=params, timeout=REQUEST_TIMEOUT)
        response.raise_for_status()
        data = response.json()
        
        if not data or len(data) <= 1:
            print(f"Не найдено снапшотов для {base_url}")
            return []
        
        snapshots = [f"https://web.archive.org/web/{row[1]}/{row[2]}"
                    for row in data[1:]]
        return snapshots
    
    except Exception as e:
        print(f"Ошибка при получении снапшотов: {e}")
        return []

def parse_arrivals(url):
    """Улучшенный парсер таблицы прилетов с увеличенными таймаутами"""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7'
        }
        
        # Увеличиваем время ожидания ответа
        session = requests.Session()
        adapter = requests.adapters.HTTPAdapter(
            pool_connections=1,
            pool_maxsize=1,
            max_retries=3,
            pool_block=True
        )
        session.mount('https://', adapter)
        session.mount('http://', adapter)
        
        print(f"Загрузка страницы {url} (таймаут {REQUEST_TIMEOUT} сек)...")
        start_time = time.time()
        response = session.get(url, headers=headers, timeout=REQUEST_TIMEOUT)
        response.raise_for_status()
        print(f"Страница загружена за {time.time() - start_time:.2f} сек")
        
        # Дополнительная задержка перед парсингом
        time.sleep(2)
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # 1. Попробуем найти таблицу по различным признакам
        possible_tables = []
        
        # Поиск по классам и ID
        table_selectors = [
            ('table', {'class': 'schedule-table'}),
            ('table', {'id': 'schedule-table'}),
            ('table', {'class': 'arrivals-table'}),
            ('table', {'class': 'table-schedule'}),
            ('table', {'class': 'data-table'}),
            ('table', {})
        ]
        
        for tag, attrs in table_selectors:
            tables = soup.find_all(tag, attrs)
            for table in tables:
                rows = table.find_all('tr')
                if len(rows) > 1 and len(rows[0].find_all(['th', 'td'])) >= 8:
                    possible_tables.append(table)
        
        # 2. Если нашли несколько подходящих таблиц, выбираем самую большую
        if possible_tables:
            table = max(possible_tables, key=lambda t: len(t.find_all('tr')))
            print(f"Найдена таблица с {len(table.find_all('tr'))} строками")
        else:
            print("Подходящая таблица не найдена")
            return []
        
        # Парсим таблицу
        rows = table.find_all('tr')
        arrivals = []
        
        for row in rows[1:]:  # Пропускаем заголовок
            cols = row.find_all('td')
            if len(cols) == 8:  # Только таблицы с 8 столбцами
                arrival = {
                    "Отправление": cols[0].text.strip(),
                    "Прибытие": cols[1].text.strip(),
                    "Дни полетов": cols[2].text.strip(),
                    "Период": cols[3].text.strip(),
                    "Авиакомпания": cols[4].text.strip(),
                    "Номер рейса": cols[5].text.strip(),
                    "Тип судна": cols[6].text.strip(),
                    "Аэропорт": cols[7].text.strip(),
                    "snapshot_url": url,
                    "snapshot_date": url.split('/web/')[1][:8]
                }
                arrivals.append(arrival)
        
        return arrivals
    
    except Exception as e:
        print(f"Ошибка при парсинге {url}: {str(e)[:200]}")
        # Сохраняем HTML для отладки
        with open(f"error_{url.split('/')[-2]}.html", "w", encoding="utf-8") as f:
            f.write(response.text if 'response' in locals() else "No response")
        return []

def main():
    base_url = "https://pkc.aero/schedule/"
    start_year = 2019
    end_year = 2025
    
    print(f"Поиск снапшотов для {base_url} с {start_year} по {end_year}...")
    snapshots = get_wayback_snapshots(base_url, start_year, end_year)
    
    if not snapshots:
        print("Не найдено доступных снапшотов.")
        return
    
    print(f"Найдено {len(snapshots)} снапшотов. Начинаем парсинг...")
    print(f"Задержка между запросами: {DELAY_BETWEEN_REQUESTS} сек")
    
    all_arrivals = []
    
    for i, url in enumerate(snapshots, 1):
        print(f"\n[{i}/{len(snapshots)}] Обработка: {url}")
        
        arrivals = parse_arrivals(url)
        if arrivals:
            all_arrivals.extend(arrivals)
            print(f"Найдено {len(arrivals)} рейсов")
        else:
            print("Таблица прилетов не найдена или не содержит данных")
        
        # Увеличиваем задержку между запросами
        if i < len(snapshots):
            print(f"Ожидание {DELAY_BETWEEN_REQUESTS} сек перед следующим запросом...")
            time.sleep(DELAY_BETWEEN_REQUESTS)
    
    if all_arrivals:
        # Сохраняем в CSV
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"pkc_arrivals_{start_year}_{end_year}_{timestamp}.csv"
        
        df = pd.DataFrame(all_arrivals)
        df.to_csv(filename, index=False, encoding='utf-8-sig')
        
        print(f"\nГотово! Всего найдено {len(df)} рейсов")
        print(f"Результаты сохранены в {filename}")
    else:
        print("Не удалось найти данные о прилетах.")

if __name__ == "__main__":
    main()