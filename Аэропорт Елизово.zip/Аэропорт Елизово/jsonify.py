import csv
import json
from datetime import datetime

def parse_days(days_str):
    days_str = days_str.strip().lower()
    if "ежедневно" in days_str:
        return ["пн", "вт", "ср", "чт", "пт", "сб", "вс"]
    return [day.strip() for day in days_str.split(',')]

def normalize_period(period):
    return period.replace('\xa0', ' ')

def parse_snapshot_date(date_str):
    return datetime.strptime(date_str, "%Y%m%d").strftime("%Y-%m-%d")

def process_file(filename, has_snapshot=False, default_date=None):
    data = []
    with open(filename, encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        print("Заголовки:", reader.fieldnames)  # Отладка
        for row in reader:
            entry = {
                "Дата расписания": parse_snapshot_date(row["snapshot_date"]) if has_snapshot else default_date,
                "Отправление": row["Отправление"],
                "Прибытие": row["Прибытие"],
                "Дни полетов": parse_days(row["Дни полетов"]),
                "Период": normalize_period(row["Период"]),
                "Авиакомпания": row["Авиакомпания"],
                "Номер рейса": row["Номер рейса"],
                "Тип судна": row["Тип судна"],
                "Аэропорт": row["Аэропорт"]
            }
            data.append(entry)
    return data

# Обработка файлов
file1_json = process_file("Аэропорт Елизово/current_flights.csv", has_snapshot=False, default_date="2024-05-15")
file2_json = process_file("Аэропорт Елизово/archive_flights.csv", has_snapshot=True)

# Объединение результатов
all_flights = file1_json + file2_json

# Сохранение в JSON
with open("flights.json", "w", encoding="utf-8") as out:
    json.dump(all_flights, out, ensure_ascii=False, indent=4)
