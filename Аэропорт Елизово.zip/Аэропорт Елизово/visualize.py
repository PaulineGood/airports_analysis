import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import Patch
import textwrap

def load_data(archive_file, current_file):
    """Загрузка данных с разными форматами дат"""
    # Загрузка архивных данных (со snapshot_date)
    df_archive = pd.read_csv(archive_file, encoding='utf-8-sig')
    df_archive['Дата'] = pd.to_datetime(df_archive['snapshot_date'], format='%Y%m%d', errors='coerce')
    
    # Загрузка актуальных данных (без snapshot_date)
    df_current = pd.read_csv(current_file, encoding='utf-8-sig')
    df_current['Дата'] = pd.to_datetime(df_current['Прибытие'].str.split().str[0], errors='coerce')
    
    # Обработка времени прибытия
    for df in [df_archive, df_current]:
        df['Час прибытия'] = pd.to_datetime(df['Прибытие'], errors='coerce').dt.hour
    
    # Разметка периодов (2022 включен в "После 2022")
    df_archive['Период'] = df_archive['Дата'].dt.year.apply(lambda x: 'После 2022' if x >= 2022 else 'До 2022')
    df_current['Период'] = df_current['Дата'].dt.year.apply(lambda x: 'После 2022' if x >= 2022 else 'До 2022')
    
    # Объединение данных
    df = pd.concat([df_archive, df_current], ignore_index=True)
    df['Год'] = df['Дата'].dt.year
    df['Месяц'] = df['Дата'].dt.month
    df['День недели'] = df['Дата'].dt.day_name()
    
    return df.dropna(subset=['Дата'])

# Настройка стиля графиков
sns.set_theme(style="whitegrid", font_scale=1.1)
plt.rcParams['figure.figsize'] = (14, 8)
plt.rcParams['grid.alpha'] = 0.3

# Новая приятная палитра
PALETTE = {
    'До 2022': '#3498db',  # Красивый синий
    'После 2022': '#e74c3c'  # Теплый красный
}

def wrap_labels(labels, width=15):
    """Перенос текста для длинных названий"""
    return [textwrap.fill(text, width=width) for text in labels]

def plot_top_10(data, column, title, palette=PALETTE):
    """Универсальная функция для построения топ-10 графиков"""
    # Получаем топ-10 значений
    top_10 = data[column].value_counts().head(10).index
    
    # Создаем подрезанные названия для отображения
    shortened_labels = [label[:20] + '...' if len(label) > 23 else label 
                       for label in top_10]
    
    # Фильтруем данные
    df_top = data[data[column].isin(top_10)]
    
    # Строим график
    plt.figure(figsize=(14, 8))
    ax = sns.countplot(
        data=df_top,
        y=column,
        hue='Период',
        palette=palette,
        order=top_10
    )
    
    # Настройка внешнего вида
    plt.title(f'Топ-10 {title}', fontsize=16, pad=20)
    plt.xlabel('Количество рейсов', fontsize=14)
    plt.ylabel('')
    
    # Устанавливаем сокращенные названия
    ax.set_yticklabels(wrap_labels(shortened_labels))
    
    # Добавляем сетку
    plt.grid(True, axis='x', linestyle='--', alpha=0.6)
    
    # Настраиваем легенду
    plt.legend(title='Период', title_fontsize='13', fontsize='12')
    
    # Добавляем значения на столбцы
    for p in ax.patches:
        width = p.get_width()
        if width > 0:
            ax.text(width + 5, p.get_y() + p.get_height()/2.,
                   f'{int(width)}',
                   ha='left', va='center', fontsize=11)
    
    plt.tight_layout()
    plt.show()
    
def plot_top_10(data, column, title, palette=PALETTE, save_path=None):
    """Универсальная функция для построения и сохранения топ-10 графиков"""
    # Получаем топ-10 значений
    top_10 = data[column].value_counts().head(10).index
    
    # Создаем подрезанные названия для отображения
    shortened_labels = [label[:20] + '...' if len(label) > 23 else label 
                       for label in top_10]
    
    # Фильтруем данные
    df_top = data[data[column].isin(top_10)]
    
    # Создаем фигуру
    plt.figure(figsize=(14, 8))
    ax = sns.countplot(
        data=df_top,
        y=column,
        hue='Период',
        palette=palette,
        order=top_10
    )
    
    # Настройка внешнего вида
    plt.title(f'Топ-10 {title}', fontsize=16, pad=20)
    plt.xlabel('Количество рейсов', fontsize=14)
    plt.ylabel('')
    
    # Устанавливаем сокращенные названия
    ax.set_yticklabels(wrap_labels(shortened_labels))
    
    # Добавляем сетку
    plt.grid(True, axis='x', linestyle='--', alpha=0.6)
    
    # Настраиваем легенду
    plt.legend(title='Период', title_fontsize='13', fontsize='12')
    
    # Добавляем значения на столбцы
    for p in ax.patches:
        width = p.get_width()
        if width > 0:
            ax.text(width + 5, p.get_y() + p.get_height()/2.,
                   f'{int(width)}',
                   ha='left', va='center', fontsize=11)
    
    plt.tight_layout()
    
    # Сохраняем график, если указан путь
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
    
    plt.show()
    plt.close()  # Важно: закрываем фигуру после отображения

def plot_flights_by_month(df, save_path=None):
    """
    Построение графика общего количества перелетов по месяцам (без учета года и периодов)
    """
    # Группируем данные по месяцу и суммируем
    monthly_data = df['Месяц'].value_counts().sort_index()
    
    # Создаем фигуру
    plt.figure(figsize=(14, 7))
    
    # Построение столбчатой диаграммы
    ax = sns.barplot(x=monthly_data.index, y=monthly_data.values, color=PALETTE['После 2022'])
    
    # Настройка внешнего вида
    plt.title('Общее количество перелетов по месяцам (Елизово)', fontsize=16, pad=20)
    plt.xlabel('Месяц', fontsize=14)
    plt.ylabel('Количество рейсов', fontsize=14)
    plt.xticks(range(12), ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 
                          'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек'])
    
    # Добавляем сетку
    plt.grid(True, axis='y', linestyle='--', alpha=0.6)
    
    # Добавляем значения на столбцы
    for p in ax.patches:
        height = p.get_height()
        if height > 0:
            ax.text(p.get_x() + p.get_width()/2., height + 5,
                   f'{int(height)}',
                   ha='center', fontsize=11)
    
    plt.tight_layout()
    
    # Сохраняем график, если указан путь
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
    
    plt.show()
    plt.close()

def plot_all_charts(df):
    """Построение и сохранение всех графиков с новым дизайном"""
    
    # Создаем папку для сохранения, если её нет
    import os
    os.makedirs('графики', exist_ok=True)
    
    # 1. Количество рейсов по годам
    plt.figure(figsize=(14, 7))
    ax = sns.countplot(data=df, x='Год', hue='Период', palette=PALETTE)
    plt.title('Количество рейсов по годам', fontsize=16, pad=20)
    plt.xlabel('Год', fontsize=14)
    plt.ylabel('Количество рейсов', fontsize=14)
    plt.legend(title='Период', title_fontsize='13', fontsize='12')
    plt.grid(True, axis='y', linestyle='--', alpha=0.6)
    
    for p in ax.patches:
        height = p.get_height()
        if height > 0:
            ax.text(p.get_x() + p.get_width()/2., height + 2,
                   f'{int(height)}',
                   ha='center', fontsize=11)
    
    plt.tight_layout()
    plt.savefig('графики/рейсы_по_годам.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 2. Сезонность рейсов (по месяцам)
    plt.figure(figsize=(14, 7))
    ax = sns.countplot(data=df, x='Месяц', hue='Период', palette=PALETTE)
    plt.title('Сезонность рейсов по месяцам', fontsize=16, pad=20)
    plt.xlabel('Месяц', fontsize=14)
    plt.ylabel('Количество рейсов', fontsize=14)
    plt.xticks(range(12), ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 
                          'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек'])
    plt.legend(title='Период', title_fontsize='13', fontsize='12')
    plt.grid(True, axis='y', linestyle='--', alpha=0.6)
    
    for p in ax.patches:
        height = p.get_height()
        if height > 0:
            ax.text(p.get_x() + p.get_width()/2., height + 2,
                   f'{int(height)}',
                   ha='center', fontsize=11)
    
    plt.tight_layout()
    plt.savefig('графики/сезонность_по_месяцам.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 3. Топ-10 авиакомпаний
    plot_top_10(df, 'Авиакомпания', 'авиакомпаний', 
               save_path='графики/топ10_авиакомпаний.png')
    
    # 4. Топ-10 аэропортов вылета
    plot_top_10(df, 'Аэропорт', 'аэропортов вылета',
               save_path='графики/топ10_аэропортов.png')
    
    # 5. Распределение по дням недели
    plt.figure(figsize=(14, 7))
    weekday_order = ['Monday', 'Tuesday', 'Wednesday', 
                    'Thursday', 'Friday', 'Saturday', 'Sunday']
    ax = sns.countplot(
        data=df, 
        x='День недели', 
        hue='Период', 
        palette=PALETTE,
        order=weekday_order
    )
    plt.title('Распределение рейсов по дням недели', fontsize=16, pad=20)
    plt.xlabel('День недели', fontsize=14)
    plt.ylabel('Количество рейсов', fontsize=14)
    plt.xticks(rotation=45)
    plt.legend(title='Период', title_fontsize='13', fontsize='12')
    plt.grid(True, axis='y', linestyle='--', alpha=0.6)
    
    for p in ax.patches:
        height = p.get_height()
        if height > 0:
            ax.text(p.get_x() + p.get_width()/2., height + 2,
                   f'{int(height)}',
                   ha='center', fontsize=11)
    
    plt.tight_layout()
    plt.savefig('графики/распределение_по_дням.png', dpi=300, bbox_inches='tight')
    plt.close()
    
    # 6. Топ-10 типов воздушных судов
    plot_top_10(df, 'Тип судна', 'типов воздушных судов',
               save_path='графики/топ10_типов_судов.png')
    
    # 7. Распределение по времени суток
    plt.figure(figsize=(14, 7))
    ax = sns.countplot(data=df, x='Час прибытия', hue='Период', palette=PALETTE)
    plt.title('Распределение рейсов по времени прибытия', fontsize=16, pad=20)
    plt.xlabel('Час прибытия', fontsize=14)
    plt.ylabel('Количество рейсов', fontsize=14)
    plt.legend(title='Период', title_fontsize='13', fontsize='12')
    plt.grid(True, axis='y', linestyle='--', alpha=0.6)
    
    # 8. Количество перелетов по месяцам (без учета года)
    plot_flights_by_month(df, save_path='графики/перелеты_по_месяцам_без_года.png')
    
    for p in ax.patches:
        height = p.get_height()
        if height > 0:
            ax.text(p.get_x() + p.get_width()/2., height + 2,
                   f'{int(height)}',
                   ha='center', fontsize=11)
    
    plt.tight_layout()
    plt.savefig('графики/распределение_по_часам.png', dpi=300, bbox_inches='tight')
    plt.close()


def main():
    try:
        print("Загрузка данных...")
        df = load_data('archive_flights.csv', 'current_flights.csv')
        
        print("\nПостроение графиков с улучшенным дизайном...")
        plot_all_charts(df)
        
        print("\nВизуализация завершена успешно!")
        
    except Exception as e:
        print(f"\nОшибка: {str(e)}")

if __name__ == "__main__":
    main()