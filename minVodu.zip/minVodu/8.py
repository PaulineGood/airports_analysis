import json
from datetime import datetime
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

# Загрузка данных
with open('flightera_parsed_full1.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# Классификация авиакомпаний
company_origin = {
    "Aeroflot": "RU", "Alrosa Avia": "RU", "Angara Airlines": "RU", "Azimuth": "RU",
    "Azimuth Airlines": "RU", "Azur Air": "RU", "IrAero": "RU", "Izhavia": "RU",
    "NordStar Airlines": "RU", "Nordavia": "RU", "Nordwind Airlines": "RU",
    "Pegas Fly": "RU", "Pobeda": "RU", "Red Wings": "RU", "Rossiya": "RU",
    "Royal Flight": "RU", "Rusline": "RU", "S7": "RU", "Severstal": "RU",
    "UTair Aviation": "RU", "Ural Airlines": "RU", "Yakutia Airlines": "RU",
    "Yamal Airlines": "RU", "Volga": "RU", "Sirius": "RU",

    "AZAL Azerbaijan Airlines": "INTL", "Air Cal%C3%A9donie": "INTL", "AirBlue": "INTL",
    "Aircompany Armenia": "INTL", "Airzena Georgian Airways": "INTL",
    "Atlantis European Airways": "INTL", "Ellinair": "INTL", "FlyOne Armenia": "INTL",
    "Meraj Airlines": "INTL", "Pegasus": "INTL", "SCAT Air": "INTL",
    "Sky Regional Airlines": "INTL", "Southwind Airlines": "INTL", "Taron": "INTL",
    "Uzbekistan Airways": "INTL", "flydubai": "INTL", "Private owner": "INTL",
    "I": "INTL", "NA": "INTL", "Alanna": "INTL"
}

# Сбор уникальных компаний по периодам
before_set = set()
after_set = set()

for flight in data:
    company = flight.get("Авиакомпания")
    date_str = flight.get("Дата расписания")
    if not company or not date_str:
        continue

    company = company.strip()
    try:
        date = datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        continue

    if date.year <= 2022:
        before_set.add(company)
    else:
        after_set.add(company)


# Подсчет по категориям
def count_by_origin(company_set):
    ru = sum(1 for c in company_set if company_origin.get(c, 'INTL') == 'RU')
    intl = sum(1 for c in company_set if company_origin.get(c, 'INTL') == 'INTL')
    return ru, intl


ru_before, intl_before = count_by_origin(before_set)
ru_after, intl_after = count_by_origin(after_set)

# Подготовка данных
labels = ['До 2022', 'После 2022']
x = np.arange(len(labels))  # [0, 1]
bar_width = 0.35

# Данные
ru_counts = [ru_before, ru_after]
intl_counts = [intl_before, intl_after]

# Построение графика
plt.figure(figsize=(8, 6))
plt.bar(x - bar_width / 2, ru_counts, width=bar_width, color='orange', label='Российские')
plt.bar(x + bar_width / 2, intl_counts, width=bar_width, color='steelblue', label='Иностранные')

plt.xticks(x, labels)
plt.ylabel('Количество уникальных авиакомпаний')
plt.title('Сравнение количества авиакомпаний до и после 2022 года')
plt.legend()
plt.grid(axis='y', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()
