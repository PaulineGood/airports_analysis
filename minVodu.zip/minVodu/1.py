from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup
from tqdm import tqdm
import requests
import time

# === Настройка Selenium ===
chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")

# Укажи свой путь к chromedriver
driver_path = "C:/Users/danii/Downloads/chromedriver_win32/chromedriver.exe"

# === Список архивных URLов (в формате Wayback Machine) ===
archive_sources = ["https://web.archive.org/web/20241015000000*/https://tolmachevo.ru/"

]

ARCHIVE_PREFIX = "https://web.archive.org"
MAX_RETRIES = 6
all_working_links = {}

# === Обход всех сайтов ===
for archive_url in archive_sources:
    print(f"\n🔍 Проверка сайта: {archive_url}")
    site_working_links = []
    try:
        driver = webdriver.Chrome(service=Service(driver_path), options=chrome_options)
        driver.get(archive_url)
        time.sleep(10)

        soup = BeautifulSoup(driver.page_source, "html.parser")
        driver.quit()

        calendar_grid = soup.select_one("div.calendar-grid")
        if not calendar_grid:
            print("⚠️ Календарь не найден, пропускаем.")
            continue

        raw_links = calendar_grid.select("div.calendar-day a[href]")
        archive_links = list(set(
            ARCHIVE_PREFIX + a['href'] for a in raw_links if "/web/" in a['href']
        ))

        print(f"🔗 Найдено {len(archive_links)} ссылок. Проверяем...\n")

        for link in tqdm(archive_links):
            for attempt in range(MAX_RETRIES):
                try:
                    res = requests.get(link, timeout=60)
                    if res.status_code == 200:
                        site_working_links.append(link)
                        break
                except requests.RequestException:
                    time.sleep(2)
            time.sleep(1)

        all_working_links[archive_url] = sorted(set(site_working_links))
        print(f"✅ Рабочих ссылок: {len(site_working_links)}")

    except Exception as e:
        print(f"❌ Ошибка при обработке {archive_url}: {e}")
        continue

# === Сохраняем результат ===
with open("working_links_all_sites.txt", "w", encoding="utf-8") as f:
    for source, links in all_working_links.items():
        f.write(f"\n=== {source} ===\n")
        for link in links:
            f.write(link + "\n")

# ... (всё остальное остаётся без изменений выше)
print("\n✅ Готово. Список рабочих ссылок:\n")
print("urls = [")
for source, links in all_working_links.items():
    for link in links:
        print(f'    "{link}",')
print("]")

