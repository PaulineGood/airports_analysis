import json
from collections import defaultdict
from datetime import datetime
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Загрузка JSON
with open('flightera_parsed_full1.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# Подсчёт рейсов
counts = defaultdict(lambda: {'До 2022': 0, 'После 2022': 0})

for flight in data:
    date_str = flight.get("Дата расписания")
    airport = flight.get("Аэропорт")
    if not date_str or not airport:
        continue
    try:
        date = datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        continue

    if date.year <= 2022:
        counts[airport]['До 2022'] += 1
    else:
        counts[airport]['После 2022'] += 1

# Подготовка данных
records = []
for airport, vals in counts.items():
    records.append({'Аэропорт': airport, 'Период': 'До 2022', 'Рейсы': vals['До 2022']})
    records.append({'Аэропорт': airport, 'Период': 'После 2022', 'Рейсы': vals['После 2022']})

df = pd.DataFrame(records)

# Отбор топ-10 по сумме
top_airports = df.groupby('Аэропорт')['Рейсы'].sum().nlargest(10).index
df_top = df[df['Аэропорт'].isin(top_airports)]

# Сортировка аэропортов по сумме
airport_order = df_top.groupby('Аэропорт')['Рейсы'].sum().sort_values().index

# Построение графика
plt.figure(figsize=(10, 6))
sns.barplot(
    data=df_top,
    y='Аэропорт',
    x='Рейсы',
    hue='Период',
    order=airport_order,
    palette={'До 2022': 'steelblue', 'После 2022': 'indianred'}
)

plt.title('Топ-10 аэропортов вылета')
plt.xlabel('Количество рейсов')
plt.ylabel('')
plt.grid(axis='x', linestyle='--', alpha=0.5)
plt.legend(title='Период')
plt.tight_layout()
plt.show()
