import undetected_chromedriver as uc
from bs4 import BeautifulSoup
import time
import re
import json

weekday_map = {
    "Пн": "Понедельник",
    "Вт": "Вторник",
    "Ср": "Среда",
    "Чт": "Четверг",
    "Пт": "Пятница",
    "Сб": "Суббота",
    "Вс": "Воскресенье"
}


def parse_flights_flightera(urls):
    # ВНИМАНИЕ: headless убран!
    options = uc.ChromeOptions()
    options.add_argument("--start-maximized")
    driver = uc.Chrome(options=options)

    all_flights = []

    for url in urls:
        print(f"\n[🔄] Обрабатываем URL: {url}")
        try:
            print(f"[🔄] Открываем браузер: {url}")
            driver.get(url)

            # Дать Cloudflare отработать
            print("[⏳] Ждём прохождения защиты...")
            time.sleep(12)

            # Дополнительно: прокрутка, чтобы всё догрузилось
            driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(3)

            soup = BeautifulSoup(driver.page_source, "html.parser")

            table = soup.select_one("table.table-auto")
            if not table:
                print("[❌] Таблица не найдена (возможно Cloudflare)")
                with open(f"debug_page_{url.split('/')[-1]}.html", "w", encoding="utf-8") as f:
                    f.write(soup.prettify())
                continue

            print("[✅] Таблица найдена")
            flights = []

            for row in table.select("tbody > tr"):
                try:
                    date_link = row.select_one("td:nth-of-type(1) a:not(.anchor)")
                    schedule_date = re.search(r'/URMM/(\d{4}-\d{2}-\d{2})', date_link['href']).group(
                        1) if date_link and 'href' in date_link.attrs else None

                    weekday_abbr = date_link.text.strip().split(",")[0]

                    # 1. Сначала убедимся, что мы нашли нужную ссылку
                    date_link = row.select_one("td:nth-of-type(2) a")  # Обратите внимание - второй столбец!
                    match = re.search(r'/flight/([^/]+/.+)$', date_link['href'])
                    date_match = match.group(1)

                    airline = date_match.split('-')[0].replace('+', ' ')

                    # Выведет только название авиакомпании
                    flight_number = date_match.split('/')[-1]  # A46021

                    airport = date_match.split('Vody')[-1].split('/')[0]

                    c = row.select_one("td:nth-of-type(2) span")
                    if c:  # Проверяем, что элемент найден
                        flight_number = c.text.strip()  # Получаем текст и убираем лишние пробелы
                        aircraft_type = (flight_number)  # AZO6307
                    else:
                        aircraft_type = None
                    departure_time1 = row.select_one("td:nth-of-type(1) span")

                    time_text = departure_time1.text.strip()
                    departure_time = time_text.split()[2]

                    flights.append({
                        "Дата расписания": schedule_date,
                        "Отправление": departure_time,
                        "Прибытие": None,
                        "Дни полетов": [weekday_abbr],
                        "Период": None,
                        "Авиакомпания": airline,
                        "Номер рейса": flight_number,
                        "Тип судна": aircraft_type,
                        "Аэропорт": airport
                    })

                except Exception as e:
                    print(f"[⚠️] Ошибка обработки строки в URL {url}: {e}")
                    continue

            print(f"[ℹ️] Найдено {len(flights)} рейсов для URL: {url}")
            all_flights.extend(flights)

        except Exception as e:
            print(f"[❌] Ошибка при обработке URL {url}: {e}")
            continue

    driver.quit()
    return all_flights


from datetime import datetime, timedelta


def generate_flightera_urls():
    base_url = "https://www.flightera.net/ru/airport/Mineralnye%20Vody/URMM/departure/{date}%2000_00?"

    start_date = datetime(2019, 1, 1)
    end_date = datetime(2025, 4, 30)  # Апрель 2025

    urls = []
    current_date = start_date

    while current_date <= end_date:
        date_str = current_date.strftime("%Y-%m-%d")
        urls.append(base_url.format(date=date_str))
        current_date += timedelta(days=1)

    return urls


# Пример использования:

if __name__ == '__main__':
    urls = generate_flightera_urls()
    flights = parse_flights_flightera(urls)

    with open("flightera_parsed_full.json", "w", encoding="utf-8") as f:
        json.dump(flights, f, indent=2, ensure_ascii=False)
