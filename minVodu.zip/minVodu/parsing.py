from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
from datetime import datetime
import time as tm
import re

# Карта преобразования дней недели
weekday_map = {
    'Monday': 'пн',
    'Tuesday': 'вт',
    'Wednesday': 'ср',
    'Thursday': 'чт',
    'Friday': 'пт',
    'Saturday': 'сб',
    'Sunday': 'вс'
}

def parse_date_from_url(url):
    match = re.search(r'web/(\d{4})(\d{2})(\d{2})', url)
    if match:
        year, month, day = map(int, match.groups())
        date_obj = datetime(year, month, day)
        return date_obj.strftime("%Y-%m-%d"), date_obj.strftime("%A")
    return "Неизвестно", "Неизвестно"

def determine_flight_type(flight_data):
    registration_fields = [
        'Стойка регистрации',
        'Начало регистрации',
        'Посадка на борт',
        'Сектор выхода на посадку'
    ]
    for field in registration_fields:
        if flight_data.get(field) not in [None, 'None', '']:
            return 'Вылет'
    if flight_data.get('Направление', '').lower().find('прилет') != -1:
        return 'Прилет'
    return 'Прилет'

def clean_flight_data(flight_data):
    if flight_data.get('Тип рейса') == 'Прилет':
        for key in ['Стойка регистрации', 'Начало регистрации',
                    'Посадка на борт', 'Сектор выхода на посадку']:
            flight_data.pop(key, None)
    return flight_data

def parse_archive_flights(url):
    try:
        current_date, current_weekday = parse_date_from_url(url)

        chrome_options = Options()
        chrome_options.add_argument("--headless")
        driver = webdriver.Chrome(
            service=Service(ChromeDriverManager().install()),
            options=chrome_options
        )

        print(f"[Загрузка] {url}")
        driver.get(url)
        tm.sleep(5)

        soup = BeautifulSoup(driver.page_source, 'html.parser')
        driver.quit()

        if not soup.find('body'):
            print("[Ошибка] Страница не загрузилась")
            return []

        flights = []
        for flight in soup.find_all('article', class_='flight-item'):
            data = {
                'Дата': current_date,
                'День недели': current_weekday,
                'Тип рейса': None,
                'Номер рейса': None,
                'Направление': None,
                'По расписанию': None,
                'Авиакомпания': None,
                'Тип ВС': None,
                'Стойка регистрации': None,
                'Начало регистрации': None,
                'Посадка на борт': None,
                'Сектор выхода на посадку': None
            }

            header = flight.find('div', class_='fi-header')
            if header:
                if num := header.find('span', class_='tth-flight'):
                    data['Номер рейса'] = num.get_text(strip=True)
                if time := header.find('span', class_='tth-time'):
                    data['По расписанию'] = time.get_text(strip=True)
                if status := header.find('span', class_='tth-status'):
                    data['Статус'] = status.get_text(strip=True)

            body = flight.find('div', class_='fi-body')
            if body:
                if direction := body.find('div', class_='fi-title'):
                    data['Направление'] = direction.get_text(strip=True)
                for item in body.find_all('li'):
                    text = item.get_text(" ", strip=True)
                    if 'Авиакомпания:' in text:
                        data['Авиакомпания'] = text.split(":", 1)[1].strip()
                    elif 'Тип ВС:' in text:
                        data['Тип ВС'] = text.split(":", 1)[1].strip()
                    elif 'Стойка регистрации:' in text:
                        data['Стойка регистрации'] = text.split(":", 1)[1].strip()
                    elif 'Начало регистрации:' in text:
                        data['Начало регистрации'] = text.split(":", 1)[1].strip()
                    elif 'Посадка на борт:' in text:
                        data['Посадка на борт'] = text.split(":", 1)[1].strip()
                    elif 'Сектор выхода на посадку:' in text:
                        data['Сектор выхода на посадку'] = text.split(":", 1)[1].strip()

            data['Тип рейса'] = determine_flight_type(data)
            data = clean_flight_data(data)

            if data['Тип рейса'] == 'Вылет':
                flights.append(data)

        return flights

    except Exception as e:
        print(f"[Ошибка] {str(e)}")
        return []

def transform_flights_for_output(flights):
    output = []
    for flight in flights:
        direction = flight.get("Направление", "")
        if "→" in direction:
            airport = direction.split("→")[-1].strip()
        else:
            airport = direction

        output.append({
            "Дата расписания": flight.get("Дата"),
            "Отправление": flight.get("По расписанию"),
            "Прибытие": None,
            "Дни полетов": [weekday_map.get(flight.get("День недели"), "")],
            "Период": None,
            "Авиакомпания": flight.get("Авиакомпания"),
            "Номер рейса": flight.get("Номер рейса"),
            "Тип судна": flight.get("Тип ВС"),
            "Аэропорт": airport
        })
    return output


import json

import json

if __name__ == '__main__':
    urls = ["https://web.archive.org/web/20231204052132/https://tolmachevo.ru/passengers/information/timetable/",
            "https://web.archive.org/web/20231107134822/https://tolmachevo.ru/passengers/information/timetable/",
            "https://web.archive.org/web/20231107134822/https://tolmachevo.ru/passengers/information/timetable/",
            "https://web.archive.org/web/20231025121633/https://tolmachevo.ru/passengers/information/timetable/",
            "https://web.archive.org/web/20231004054512/https://tolmachevo.ru/passengers/information/timetable/",
            "https://web.archive.org/web/20231004054512/https://tolmachevo.ru/passengers/information/timetable/",
            "https://web.archive.org/web/20231004054512/https://tolmachevo.ru/passengers/information/timetable/",
            "https://web.archive.org/web/20231204052132/https://tolmachevo.ru/passengers/information/timetable/",
            "https://web.archive.org/web/20231204052132/https://tolmachevo.ru/passengers/information/timetable/",
            "https://web.archive.org/web/20231204052132/https://tolmachevo.ru/passengers/information/timetable/",
            "https://web.archive.org/web/20231004054512/https://tolmachevo.ru/passengers/information/timetable/",
            "https://web.archive.org/web/20230822180324/https://tolmachevo.ru/passengers/information/timetable/",
            ""
    ]

    all_flights = []
    for url in urls:
        flights = parse_archive_flights(url)
        all_flights.extend(flights)

    transformed = transform_flights_for_output(all_flights)

    # Сохраняем результат в файл с соблюдением порядка ключей
    with open("departures_transformed.2023.json", "w", encoding="utf-8") as f:
        json.dump(transformed, f, ensure_ascii=False, indent=2)

    print(f"✅ Сохранено {len(transformed)} вылетов → departures_transformed.json")


