import json
from datetime import datetime
import matplotlib.pyplot as plt
import numpy as np

# Загрузка JSON
with open('flightera_parsed_full1.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# Инициализация счётчиков
seasons = ['Зима', 'Весна', 'Лето', 'Осень']
season_map = {
    1: 'Зима', 2: 'Зима', 12: 'Зима',
    3: 'Весна', 4: 'Весна', 5: 'Весна',
    6: 'Лето', 7: 'Лето', 8: 'Лето',
    9: 'Осень', 10: 'Осень', 11: 'Осень'
}

season_counts = {
    'До 2022': {'Зима': 0, 'Весна': 0, 'Лето': 0, 'Осень': 0},
    'После 2022': {'Зима': 0, 'Весна': 0, 'Лето': 0, 'Осень': 0}
}

# Подсчёт рейсов по сезону и периоду
for flight in data:
    date_str = flight.get("Дата расписания")
    if not date_str:
        continue
    try:
        date = datetime.strptime(date_str, "%Y-%m-%d")
        period = 'До 2022' if date.year <= 2022 else 'После 2022'
        season = season_map.get(date.month)
        if season:
            season_counts[period][season] += 1
    except ValueError:
        continue

# Подготовка данных к отображению
x = np.arange(len(seasons))  # позиции: 0, 1, 2, 3
width = 0.35

before = [season_counts['До 2022'][s] for s in seasons]
after = [season_counts['После 2022'][s] for s in seasons]

# Построение графика
plt.figure(figsize=(10, 6))
plt.bar(x - width/2, before, width=width, color='orange', label='До 2022')
plt.bar(x + width/2, after, width=width, color='steelblue', label='После 2022')

# Настройка осей и заголовков
plt.xticks(x, seasons)
plt.ylabel('Количество рейсов')
plt.title('Сравнение сезонности до и после 2022 года')
plt.legend()
plt.grid(axis='y', linestyle='--', alpha=0.6)
plt.tight_layout()
plt.show()
