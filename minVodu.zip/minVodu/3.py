import json
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
from collections import defaultdict

# Словарь для нормализации названий авиакомпаний (опционально)
airline_names = {
    'Pobeda': 'Победа',
    'S7 Airlines': 'S7 Airlines',
    'Red Wings': 'Red Wings',
    'UTair': 'ЮТэйр',
    'Nordwind': 'Nordwind',
    'Ural Airlines': 'Уральские авиалинии'
}

# Загрузка данных
with open('flightera_parsed_full1.json', 'r', encoding='utf-8') as f:
    flights = json.load(f)

df = pd.DataFrame(flights)

### 1. Топ направлений ###
top_destinations = df['Аэропорт'].value_counts().head(15).reset_index()
top_destinations.columns = ['Аэропорт', 'Количество рейсов']

plt.figure(figsize=(14, 8))
sns.barplot(data=top_destinations, x='Количество рейсов', y='Аэропорт', palette='viridis', orient='h')

plt.title(f'Топ-15 направлений\nВсего рейсов: {len(df)}', fontsize=16, pad=20)
plt.xlabel('Количество рейсов')
plt.ylabel('Направление')
plt.grid(axis='x', linestyle='--', alpha=0.4)
for i, value in enumerate(top_destinations['Количество рейсов']):
    plt.text(value + 0.5, i, str(value), va='center')
plt.tight_layout()
plt.savefig('gsv_top_destinations.png', dpi=300)
plt.show()


### 2. Авиакомпании ###
airline_counts = df['Авиакомпания'].value_counts()
airline_counts.index = airline_counts.index.map(lambda x: airline_names.get(x, x))

airline_df = airline_counts.reset_index()
airline_df.columns = ['Авиакомпания', 'Количество рейсов']

plt.figure(figsize=(12, 6))
sns.barplot(data=airline_df, x='Количество рейсов', y='Авиакомпания', palette='rocket', orient='h')
plt.title('Распределение рейсов по авиакомпаниям', fontsize=16)
plt.xlabel('Количество рейсов')
plt.ylabel('Авиакомпания')
plt.grid(axis='x', linestyle='--', alpha=0.4)
for i, value in enumerate(airline_df['Количество рейсов']):
    plt.text(value + 0.5, i, str(value), va='center')
plt.tight_layout()
plt.savefig('gsv_airlines.png', dpi=300)
plt.show()


### 3. Сезонность (по Периодам) ###
if 'Период' in df.columns and df['Период'].notna().any():
    df['Начало периода'] = df['Период'].str.split('-').str[0].str.strip()
    try:
        df['Год'] = pd.to_datetime(df['Начало периода'], format='%d.%m.%Y').dt.year
        yearly_stats = df['Год'].value_counts().sort_index()
        plt.figure(figsize=(12, 6))
        yearly_stats.plot(kind='bar', color='skyblue')
        plt.title('Динамика количества рейсов по годам', fontsize=16)
        plt.xlabel('Год')
        plt.ylabel('Количество рейсов')
        plt.grid(axis='y', linestyle='--', alpha=0.4)
        for i, value in enumerate(yearly_stats):
            plt.text(i, value + 0.5, str(value), ha='center')
        plt.xticks(rotation=45)
        plt.tight_layout()
        plt.savefig('gsv_yearly_dynamics.png', dpi=300)
        plt.show()
    except Exception as e:
        print("Не удалось проанализировать временные периоды:", e)


### 4. Дни недели ###
if 'Дни полетов' in df.columns:
    days_mapping = {
        'пн': 'Понедельник', 'вт': 'Вторник', 'ср': 'Среда',
        'чт': 'Четверг', 'пт': 'Пятница', 'сб': 'Суббота', 'вс': 'Воскресенье'
    }
    day_counts = defaultdict(int)

    for days in df['Дни полетов']:
        if isinstance(days, list):
            for day in days:
                if day in days_mapping:
                    day_counts[days_mapping[day]] += 1
        elif isinstance(days, str):  # Иногда поле может быть строкой, например: "['пн','вт']"
            try:
                parsed_days = json.loads(days.replace("'", '"'))
                if isinstance(parsed_days, list):
                    for day in parsed_days:
                        if day in days_mapping:
                            day_counts[days_mapping[day]] += 1
            except:
                continue

    if day_counts:
        day_df = pd.DataFrame({
            'День недели': list(day_counts.keys()),
            'Количество рейсов': list(day_counts.values())
        }).sort_values('Количество рейсов', ascending=False)

        plt.figure(figsize=(10, 6))
        sns.barplot(x='Количество рейсов', y='День недели', data=day_df, palette='coolwarm', orient='h')
        plt.title('Распределение рейсов по дням недели', fontsize=16)
        plt.xlabel('Количество рейсов')
        plt.ylabel('День недели')
        plt.grid(axis='x', linestyle='--', alpha=0.4)
        for i, value in enumerate(day_df['Количество рейсов']):
            plt.text(value + 0.5, i, str(value), va='center')
        plt.tight_layout()
        plt.savefig('gsv_weekdays.png', dpi=300)
        plt.show()
    else:
        print("Нет данных для построения распределения по дням недели.")
