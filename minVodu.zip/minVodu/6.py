import json
from collections import defaultdict
from datetime import datetime
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Загрузка JSON
with open('flightera_parsed_full1.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# Подсчет рейсов по периодам
counts = defaultdict(lambda: {'До 2022': 0, 'После 2022': 0})
total_flights = 0

for flight in data:
    date_str = flight.get("Дата расписания")
    airport = flight.get("Аэропорт")
    if not date_str or not airport:
        continue
    try:
        date = datetime.strptime(date_str, "%Y-%m-%d")
    except ValueError:
        continue

    total_flights += 1
    if date.year <= 2022:
        counts[airport]['До 2022'] += 1
    else:
        counts[airport]['После 2022'] += 1

# Создание DataFrame
df = pd.DataFrame([
    {
        'Аэропорт': airport,
        'До 2022': vals['До 2022'],
        'После 2022': vals['После 2022'],
        'Разница': vals['После 2022'] - vals['До 2022']
    }
    for airport, vals in counts.items()
])

# Топы
df_increase = df.sort_values(by='Разница', ascending=False).head(10)
df_decrease = df.sort_values(by='Разница').head(10)

# Построение графиков
fig, axes = plt.subplots(1, 2, figsize=(16, 8), sharex=False)

# График прироста — ЗЕЛЁНЫЙ
sns.barplot(
    data=df_increase,
    y='Аэропорт',
    x='Разница',
    ax=axes[0],
    color='green',
    label='Прирост рейсов'
)
for i, val in enumerate(df_increase['Разница']):
    axes[0].text(val + max(df_increase['Разница']) * 0.01, i, str(val),
                 va='center', ha='left', color='black', weight='normal', fontsize=11)

axes[0].set_xlim(0, max(df_increase['Разница']) * 1.1)
axes[0].set_title('Наибольший прирост рейсов')
axes[0].set_xlabel('Количество рейсов')
axes[0].set_ylabel('Направления')
axes[0].legend(loc='lower right')

# График убыли — КРАСНЫЙ

sns.barplot(
    data=df_decrease,
    y='Аэропорт',
    x='Разница',
    ax=axes[1],
    color='red',
    label='Убыль рейсов'
)
for i, val in enumerate(df_decrease['Разница']):
    axes[1].text(val - max(abs(df_decrease['Разница'])) * 0.01, i, str(val),
                 va='center', ha='right', color='black', weight='normal', fontsize=11)

axes[1].set_xlim(min(df_decrease['Разница']) * 1.1, 0)
axes[1].set_title('Наибольшая убыль рейсов')
axes[1].set_xlabel('Количество рейсов')

# Перенос оси Y направо:
axes[1].yaxis.tick_right()
axes[1].yaxis.set_label_position("right")
axes[1].set_ylabel('Направления')

# Легенда справа
axes[1].legend(loc='lower left')


# Заголовки и аннотации
fig.suptitle('Изменение количества полетов аэропорта Минеральные воды после 2022 года',
             fontsize=16, fontweight='bold')

# Подзаголовок с датой и числом рейсов — сразу под основным заголовком
fig.subplots_adjust(top=0.88)
plt.figtext(0.5, 0.91,
            f"01.01.2019 г. - 01.04.2025 г. | Всего рейсов: {total_flights}",
            ha="center", fontsize=12, color='gray')

plt.tight_layout(rect=[0, 0.05, 1, 0.88])
plt.show()
