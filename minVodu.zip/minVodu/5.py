import json
from collections import Counter
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

# Загрузка JSON
with open('flightera_parsed_full1.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# Подсчёт дней недели
day_map = {
    "Пн": "Понедельник",
    "Вт": "Вторник",
    "Ср": "Среда",
    "Чт": "Четверг",
    "Пт": "Пятница",
    "Сб": "Суббота",
    "Вс": "Воскресенье"
}

counter = Counter()

for flight in data:
    days = flight.get("Дни полетов")
    if not days:
        continue
    for day in days:
        full_day = day_map.get(day)
        if full_day:
            counter[full_day] += 1

# Преобразование в DataFrame
df = pd.DataFrame(counter.items(), columns=['День недели', 'Количество рейсов'])
df = df.set_index('День недели').reindex([
    "Понедельник", "Вторник", "Среда", "Четверг",
    "Пятница", "Суббота", "Воскресенье"
]).reset_index()

# Цветовая шкала (градиент)
colors = sns.color_palette("coolwarm", len(df))
colors = colors[::-1]  # для соответствия градиенту на примере

# Построение графика
plt.figure(figsize=(10, 6))
bars = plt.barh(df['День недели'], df['Количество рейсов'], color=colors)

# Добавление подписей
for bar in bars:
    width = bar.get_width()
    plt.text(width + 50, bar.get_y() + bar.get_height()/2, str(width), va='center')

# Оформление
plt.title('Распределение рейсов по дням недели', fontsize=14)
plt.xlabel('Количество рейсов')
plt.ylabel('День недели')
plt.grid(axis='x', linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()
