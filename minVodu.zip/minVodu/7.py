import json
from datetime import datetime
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Загрузка JSON
with open('flightera_parsed_full1.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# Извлекаем часы вылета
departure_hours = []

for flight in data:
    time_str = flight.get("Отправление")
    if not time_str:
        continue
    try:
        time_obj = datetime.strptime(time_str, "%H:%M")
        departure_hours.append(time_obj.hour)
    except ValueError:
        continue  # некорректное время

# Преобразуем в DataFrame
df = pd.DataFrame({'Час вылета': departure_hours})

# Стиль оформления
sns.set(style="whitegrid")

plt.figure(figsize=(12, 6))
sns.histplot(
    data=df,
    x='Час вылета',
    bins=24,
    binrange=(0, 24),
    color='skyblue',
    edgecolor='black'
)

plt.title('Распределение вылетов по времени суток', fontsize=16)
plt.xlabel('Час (0–23)', fontsize=12)
plt.ylabel('Количество рейсов', fontsize=12)
plt.xticks(range(0, 24))
plt.grid(axis='y', linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()
