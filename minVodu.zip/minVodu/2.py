import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import json

# Загрузка JSON
with open('flightera_parsed_full1.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# Датафрейм
df = pd.DataFrame(data)

# Анализ популярных направлений
top_destinations = df['Аэропорт'].value_counts().head(15).reset_index()
top_destinations.columns = ['Аэропорт', 'Количество рейсов']

# Построение графика
plt.figure(figsize=(12, 8))
sns.barplot(
    data=top_destinations,
    x='Количество рейсов',
    y='Аэропорт',
    palette='viridis',
    orient='h'
)

plt.title(f'Топ-15 направлений из аэропорта Минеральные Воды\nВсего рейсов: {len(df)}', fontsize=16)
plt.xlabel('Количество рейсов')
plt.ylabel('Направление')
plt.grid(axis='x', linestyle='--', alpha=0.5)

plt.tight_layout()
plt.show()
