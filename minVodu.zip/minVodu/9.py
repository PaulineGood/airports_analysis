import json
from datetime import datetime
import matplotlib.pyplot as plt
import pandas as pd

# Загрузка данных
with open('flightera_parsed_full1.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

# Подсчет рейсов по месяцам
month_counts = [0] * 12  # индекс 0 - Янв, ..., 11 - Дек
season_counts = {
    'Зима': 0,
    'Весна': 0,
    'Лето': 0,
    'Осень': 0
}

for flight in data:
    date_str = flight.get("Дата расписания")
    if not date_str:
        continue
    try:
        date = datetime.strptime(date_str, "%Y-%m-%d")
        month = date.month
        month_counts[month - 1] += 1

        # Классификация по сезонам
        if month in [12, 1, 2]:
            season_counts['Зима'] += 1
        elif month in [3, 4, 5]:
            season_counts['Весна'] += 1
        elif month in [6, 7, 8]:
            season_counts['Лето'] += 1
        elif month in [9, 10, 11]:
            season_counts['Осень'] += 1
    except ValueError:
        continue

# Названия месяцев
months = ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн',
          'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек']

# Построение двух графиков рядом
fig, axes = plt.subplots(1, 2, figsize=(14, 6))

# График по месяцам
axes[0].bar(months, month_counts, color='cornflowerblue', edgecolor='black')
axes[0].set_title('Сезонность по месяцам', fontsize=14)
axes[0].set_xlabel('Месяц')
axes[0].set_ylabel('Количество рейсов')
axes[0].grid(axis='y', linestyle='--', alpha=0.6)

# График по сезонам
seasons = list(season_counts.keys())
season_values = list(season_counts.values())
axes[1].bar(seasons, season_values, color='mediumpurple', edgecolor='black')
axes[1].set_title('Сезонность по временам года', fontsize=14)
axes[1].set_xlabel('Сезон')
axes[1].set_ylabel('Количество рейсов')
axes[1].grid(axis='y', linestyle='--', alpha=0.6)

plt.tight_layout()
plt.show()
