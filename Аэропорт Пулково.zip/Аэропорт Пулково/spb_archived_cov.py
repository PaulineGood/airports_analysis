import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime
import time
import random

def fetch_wayback_snapshot(url):
    """Загружает HTML через Wayback Machine с одной попыткой"""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br'
        }
        
        # Увеличенный таймаут
        response = requests.get(url, headers=headers, timeout=(15, 30))
        response.raise_for_status()
        
        if 'text/html' not in response.headers.get('Content-Type', ''):
            return None
            
        response.encoding = 'utf-8'
        return response.text
        
    except Exception as e:
        print(f"Ошибка при загрузке {url}: {str(e)}")
        return None

def parse_flights_table(html, city_name):
    """Парсит таблицу рейсов с нужными столбцами"""
    soup = BeautifulSoup(html, 'html.parser')
    
    timetable_box = soup.find('div', class_='timetable_box')
    if not timetable_box:
        return None
    
    timetable_tab = timetable_box.find('div', class_='timetable_tab')
    if not timetable_tab:
        return None
    
    table = timetable_tab.find('table')
    if not table:
        return None
    
    flights = []
    rows = table.find_all('tr')[1:]
    
    for row in rows:
        cols = row.find_all('td')
        if len(cols) < 6:
            continue
            
        days_of_week = []
        days_cell = cols[4]
        for day in days_cell.find_all('span', class_='timetable_weekday'):
            if 'selected' in day.get('class', []):
                days_of_week.append(day.get_text(strip=True))
        
        flight_data = {
            'Город': city_name,
            'Рейс': cols[0].get_text(strip=True),
            'Авиакомпания': cols[1].get_text(strip=True),
            'Дата': cols[2].get_text(strip=True),
            'Время': cols[3].get_text(strip=True),
            'Дни недели': ', '.join(days_of_week) if days_of_week else 'N/A',
            'Самолет': cols[5].get_text(strip=True) if len(cols) > 5 else 'N/A'
        }
        
        flights.append(flight_data)
    
    return pd.DataFrame(flights)

def main():
    # Шаблон ссылок для каждого города (по 3 архивные версии)
    CITY_URLS = {
        "Анапа": [
            "https://web.archive.org/web/20200930085459/https://pulkovoairport.ru/flights/schedule/?city=Анапа",
            "https://web.archive.org/web/20210121075502/https://pulkovoairport.ru/flights/schedule/?city=Анапа",
            "https://web.archive.org/web/20210420034645/https://pulkovoairport.ru/flights/schedule/?city=Анапа"
        ],
        "Апатиты": [
            "https://web.archive.org/web/20200926150557/https://pulkovoairport.ru/flights/schedule/?city=Апатиты",
            "https://web.archive.org/web/20210122123158/https://pulkovoairport.ru/flights/schedule/?city=Апатиты",
            "https://web.archive.org/web/20210420040826/https://pulkovoairport.ru/flights/schedule/?city=Апатиты"
        ],
        "Москва": [
            "https://web.archive.org/web/20210420042310/https://pulkovoairport.ru/flights/schedule/?city=Москва",
            "https://web.archive.org/web/20200926150557/https://pulkovoairport.ru/flights/schedule/?city=Москва",
            "https://web.archive.org/web/20210122123158/https://pulkovoairport.ru/flights/schedule/?city=Москва"
        ],
        "Архангельск": [
            "https://web.archive.org/web/20200925164727/https://pulkovoairport.ru/flights/schedule/?city=Архангельск",
            "https://web.archive.org/web/20210122130325/https://pulkovoairport.ru/flights/schedule/?city=Архангельск",
            "https://web.archive.org/web/20210421052846/https://pulkovoairport.ru/flights/schedule/?city=Архангельск"
        ],
        "Барнаул": [
            "https://web.archive.org/web/20210510180359/https://pulkovoairport.ru/flights/schedule/?city=Барнаул"
        ],
        "Белгород": [
            "https://web.archive.org/web/20210421044354/https://pulkovoairport.ru/flights/schedule/?city=Белгород",
            "https://web.archive.org/web/20210124054459/https://pulkovoairport.ru/flights/schedule/?city=Белгород",
            "https://web.archive.org/web/20200925160736/https://pulkovoairport.ru/flights/schedule/?city=Белгород"
        ],
        "Брянск": [
            "https://web.archive.org/web/20210415172654/https://pulkovoairport.ru/flights/schedule/?city=Брянск",
            "https://web.archive.org/web/20210116210548/https://pulkovoairport.ru/flights/schedule/?city=Брянск",
            "https://web.archive.org/web/20200930091246/https://pulkovoairport.ru/flights/schedule/?city=Брянск"
        ],
        "Владикавказ": [
            "https://web.archive.org/web/20210421055812/https://pulkovoairport.ru/flights/schedule/?city=Владикавказ",
            "https://web.archive.org/web/20210128124507/https://pulkovoairport.ru/flights/schedule/?city=Владикавказ",
            "https://web.archive.org/web/20201023221250/https://pulkovoairport.ru/flights/schedule/?city=Владикавказ",
            "https://web.archive.org/web/20200813180630/https://pulkovoairport.ru/flights/schedule/?city=Владикавказ"
        ],
        "Волгоград": [
            "https://web.archive.org/web/20210415165955/https://pulkovoairport.ru/flights/schedule/?city=Волгоград",
            "https://web.archive.org/web/20210116144943/https://pulkovoairport.ru/flights/schedule/?city=Волгоград",
            "https://web.archive.org/web/20201026041143/https://pulkovoairport.ru/flights/schedule/?city=Волгоград",
            "https://web.archive.org/web/20200810082140/https://pulkovoairport.ru/flights/schedule/?city=Волгоград"
        ],
        "Вологда": [
            "https://web.archive.org/web/20210510195800/https://pulkovoairport.ru/flights/schedule/?city=Вологда",
            "https://web.archive.org/web/20210301045547/https://pulkovoairport.ru/flights/schedule/?city=Вологда",
            "https://web.archive.org/web/20201202041006/https://pulkovoairport.ru/flights/schedule/?city=Вологда",
            "https://web.archive.org/web/20200925171802/https://pulkovoairport.ru/flights/schedule/?city=Вологда"
        ],
        "Воронеж": [
            "https://web.archive.org/web/20210415174454/https://pulkovoairport.ru/flights/schedule/?city=Воронеж",
            "https://web.archive.org/web/20210116211548/https://pulkovoairport.ru/flights/schedule/?city=Воронеж",
            "https://web.archive.org/web/20200930092708/https://pulkovoairport.ru/flights/schedule/?city=Воронеж"
        ],
        "Геленджик": [
            "https://web.archive.org/web/20200813171244/https://pulkovoairport.ru/flights/schedule/?city=Геленджик"
            # остальные ссылки не содержали рейсов, посмотрим, что скажет approx.py
        ],
        "Грозный": [
            "https://web.archive.org/web/20210415174612/https://pulkovoairport.ru/flights/schedule/?city=Грозный",
            "https://web.archive.org/web/20210116211614/https://pulkovoairport.ru/flights/schedule/?city=Грозный",
            "https://web.archive.org/web/20200928155031/https://pulkovoairport.ru/flights/schedule/?city=Грозный"
        ],
        "Екатеринбург": [
            "https://web.archive.org/web/20210415162428/https://pulkovoairport.ru/flights/schedule/?city=Екатеринбург",
            "https://web.archive.org/web/20210116202641/https://pulkovoairport.ru/flights/schedule/?city=Екатеринбург",
            "https://web.archive.org/web/20200929193803/https://pulkovoairport.ru/flights/schedule/?city=Екатеринбург"
        ],
        "Иваново": [
            "https://web.archive.org/web/20210510181501/https://pulkovoairport.ru/flights/schedule/?city=Иваново",
            "https://web.archive.org/web/20210301032415/https://pulkovoairport.ru/flights/schedule/?city=Иваново",
            "https://web.archive.org/web/20201202023900/https://pulkovoairport.ru/flights/schedule/?city=Иваново",
            "https://web.archive.org/web/20200924171202/https://pulkovoairport.ru/flights/schedule/?city=Иваново"
        ],
        "Ижевск": [
            "https://web.archive.org/web/20210422032054/https://pulkovoairport.ru/flights/schedule/?city=Ижевск",
            "https://web.archive.org/web/20210121084851/https://pulkovoairport.ru/flights/schedule/?city=Ижевск",
            "https://web.archive.org/web/20201021221516/https://pulkovoairport.ru/flights/schedule/?city=Ижевск",
            "https://web.archive.org/web/20200806134150/https://pulkovoairport.ru/flights/schedule/?city=Ижевск"
        ],
        "Иркутск": [
            "https://web.archive.org/web/20210510194424/https://pulkovoairport.ru/flights/schedule/?city=Иркутск",
            "https://web.archive.org/web/20210301044227/https://pulkovoairport.ru/flights/schedule/?city=Иркутск",
            "https://web.archive.org/web/20200924191141/https://pulkovoairport.ru/flights/schedule/?city=Иркутск",
            "https://web.archive.org/web/20201202035731/https://pulkovoairport.ru/flights/schedule/?city=Иркутск"
        ],
        "Казань": [
            "https://web.archive.org/web/20210421040640/https://pulkovoairport.ru/flights/schedule/?city=Казань",
            "https://web.archive.org/web/20210128105423/https://pulkovoairport.ru/flights/schedule/?city=Казань",
            "https://web.archive.org/web/20201023210159/https://pulkovoairport.ru/flights/schedule/?city=Казань",
            "https://web.archive.org/web/20200813163651/https://pulkovoairport.ru/flights/schedule/?city=Казань"
        ],
        "Калининград": [
            "https://web.archive.org/web/20210510191448/https://pulkovoairport.ru/flights/schedule/?city=Калининград",
            "https://web.archive.org/web/20210301040955/https://pulkovoairport.ru/flights/schedule/?city=Калининград",
            "https://web.archive.org/web/20201202032410/https://pulkovoairport.ru/flights/schedule/?city=Калининград",
            "https://web.archive.org/web/20200924181941/https://pulkovoairport.ru/flights/schedule/?city=Калининград"
        ],
        "Калуга": [
            "https://web.archive.org/web/20210421045617/https://pulkovoairport.ru/flights/schedule/?city=Калуга",
            "https://web.archive.org/web/20210124055523/https://pulkovoairport.ru/flights/schedule/?city=Калуга",
            "https://web.archive.org/web/20200925161942/https://pulkovoairport.ru/flights/schedule/?city=Калуга"
        ],
        "Кемерово": [
            "https://web.archive.org/web/20210415165200/https://pulkovoairport.ru/flights/schedule/?city=Кемерово"
        ],
        "Киров": [
            "https://web.archive.org/web/20210510195718/https://pulkovoairport.ru/flights/schedule/?city=Киров",
            "https://web.archive.org/web/20210301045331/https://pulkovoairport.ru/flights/schedule/?city=Киров",
            "https://web.archive.org/web/20201202040749/https://pulkovoairport.ru/flights/schedule/?city=Киров",
            "https://web.archive.org/web/20200924192822/https://pulkovoairport.ru/flights/schedule/?city=Киров"
        ],
        "Кострома": [
            "https://web.archive.org/web/20210420050324/https://pulkovoairport.ru/flights/schedule/?city=Кострома",
            "https://web.archive.org/web/20210122132119/https://pulkovoairport.ru/flights/schedule/?city=Кострома",
            "https://web.archive.org/web/20200928162243/https://pulkovoairport.ru/flights/schedule/?city=Кострома"
        ],
        "Краснодар": [
            "https://web.archive.org/web/20210421050831/https://pulkovoairport.ru/flights/schedule/?city=Краснодар",
            "https://web.archive.org/web/20210124060000/https://pulkovoairport.ru/flights/schedule/?city=Краснодар",
            "https://web.archive.org/web/20200925162601/https://pulkovoairport.ru/flights/schedule/?city=Краснодар",
        ],
        "Красноярск": [
            "https://web.archive.org/web/20210420045129/https://pulkovoairport.ru/flights/schedule/?city=Красноярск",
            "https://web.archive.org/web/20210122131144/https://pulkovoairport.ru/flights/schedule/?city=Красноярск",
            "https://web.archive.org/web/20200926155825/https://pulkovoairport.ru/flights/schedule/?city=Красноярск"
        ],
        "Курск": [
            "https://web.archive.org/web/20210306015331/https://pulkovoairport.ru/flights/schedule/?city=Курск",
            "https://web.archive.org/web/20201202032726/https://pulkovoairport.ru/flights/schedule/?city=Курск",
            "https://web.archive.org/web/20200924182359/https://pulkovoairport.ru/flights/schedule/?city=Курск"
        ],
        "Липецк": [
            "https://web.archive.org/web/20210421055657/https://pulkovoairport.ru/flights/schedule/?city=Липецк",
            "https://web.archive.org/web/20210124064607/https://pulkovoairport.ru/flights/schedule/?city=Липецк",
        ],
        "Махачкала": [
            "https://web.archive.org/web/20210510192722/https://pulkovoairport.ru/flights/schedule/?city=Махачкала",
            "https://web.archive.org/web/20210301042616/https://pulkovoairport.ru/flights/schedule/?city=Махачкала",
            "https://web.archive.org/web/20201202034115/https://pulkovoairport.ru/flights/schedule/?city=Махачкала",
            "https://web.archive.org/web/20200924184559/https://pulkovoairport.ru/flights/schedule/?city=Махачкала"
        ],
        "Мурманск": [
            "https://web.archive.org/web/20210116201517/https://pulkovoairport.ru/flights/schedule/?city=Мурманск",
            "https://web.archive.org/web/20210415161658/https://pulkovoairport.ru/flights/schedule/?city=Мурманск",
            "https://web.archive.org/web/20200930081147/https://pulkovoairport.ru/flights/schedule/?city=Мурманск"
        ],
        "Надым": [
            "https://web.archive.org/web/20210415180853/https://pulkovoairport.ru/flights/schedule/?city=Надым",
            "https://web.archive.org/web/20210116154956/https://pulkovoairport.ru/flights/schedule/?city=Надым",
            "https://web.archive.org/web/20201026044734/https://pulkovoairport.ru/flights/schedule/?city=Надым",
            "https://web.archive.org/web/20200810091745/https://pulkovoairport.ru/flights/schedule/?city=Надым"
        ],
        "Нальчик": [
            "https://web.archive.org/web/20201021215557/https://pulkovoairport.ru/flights/schedule/?city=Нальчик",
            "https://web.archive.org/web/20200806131637/https://pulkovoairport.ru/flights/schedule/?city=Нальчик",
        ],
        "Нарьян-Мар": [
            "https://web.archive.org/web/20210421043100/https://pulkovoairport.ru/flights/schedule/?city=Нарьян-Мар",
            "https://web.archive.org/web/20210128112713/https://pulkovoairport.ru/flights/schedule/?city=Нарьян-Мар",
            "https://web.archive.org/web/20201026040106/https://pulkovoairport.ru/flights/schedule/?city=Нарьян-Мар",
            "https://web.archive.org/web/20200813170231/https://pulkovoairport.ru/flights/schedule/?city=Нарьян-Мар"
        ],
        "Нижневартовск": [
            "https://web.archive.org/web/20201023212755/https://pulkovoairport.ru/flights/schedule/?city=Нижневартовск",
            "https://web.archive.org/web/20200813170825/https://pulkovoairport.ru/flights/schedule/?city=Нижневартовск",
        ],
        "Нижнекамск": [
            "https://web.archive.org/web/20210420041933/https://pulkovoairport.ru/flights/schedule/?city=Нижнекамск",
            "https://web.archive.org/web/20210122123937/https://pulkovoairport.ru/flights/schedule/?city=Нижнекамск",
            "https://web.archive.org/web/20200928183422/https://pulkovoairport.ru/flights/schedule/?city=Нижнекамск"
        ],
        "Новосибирск": [
            "https://web.archive.org/web/20210422031322/https://pulkovoairport.ru/flights/schedule/?city=Новосибирск",
            "https://web.archive.org/web/20210121084139/https://pulkovoairport.ru/flights/schedule/?city=Новосибирск",
            "https://web.archive.org/web/20200930093328/https://pulkovoairport.ru/flights/schedule/?city=Новосибирск"
        ],
        "Норильск": [
            "https://web.archive.org/web/20210421051640/https://pulkovoairport.ru/flights/schedule/?city=Норильск",
            "https://web.archive.org/web/20210128115733/https://pulkovoairport.ru/flights/schedule/?city=Норильск",
            "https://web.archive.org/web/20201023214237/https://pulkovoairport.ru/flights/schedule/?city=Норильск",
            "https://web.archive.org/web/20200813172837/https://pulkovoairport.ru/flights/schedule/?city=Норильск"
        ],
        "Ноябрьск": [
            "https://web.archive.org/web/20210510194317/https://pulkovoairport.ru/flights/schedule/?city=Ноябрьск",
            "https://web.archive.org/web/20210301044129/https://pulkovoairport.ru/flights/schedule/?city=Ноябрьск",
            "https://web.archive.org/web/20201202035638/https://pulkovoairport.ru/flights/schedule/?city=Ноябрьск",
            "https://web.archive.org/web/20200924191016/https://pulkovoairport.ru/flights/schedule/?city=Ноябрьск"
        ],
        "Омск": [
            "https://web.archive.org/web/20210420043339/https://pulkovoairport.ru/flights/schedule/?city=Омск",
            "https://web.archive.org/web/20210122125522/https://pulkovoairport.ru/flights/schedule/?city=Омск",
            "https://web.archive.org/web/20200926153600/https://pulkovoairport.ru/flights/schedule/?city=Омск"
        ],
        "Оренбург": [
            "https://web.archive.org/web/20210421052529/https://pulkovoairport.ru/flights/schedule/?city=Оренбург",
            "https://web.archive.org/web/20210124061858/https://pulkovoairport.ru/flights/schedule/?city=Оренбург",
            "https://web.archive.org/web/20200925164535/https://pulkovoairport.ru/flights/schedule/?city=Оренбург"
        ],
        "Пенза": [
            "https://web.archive.org/web/20200926150048/https://pulkovoairport.ru/flights/schedule/?city=Пенза"
        ],
        "Пермь": [
            "https://web.archive.org/web/20210420044309/https://pulkovoairport.ru/flights/schedule/?city=Пермь",
            "https://web.archive.org/web/20210122130559/https://pulkovoairport.ru/flights/schedule/?city=Пермь",
            "https://web.archive.org/web/20200925165024/https://pulkovoairport.ru/flights/schedule/?city=Пермь"
        ],
        "Ростов-на-Дону": [
            "https://web.archive.org/web/20210510195015/https://pulkovoairport.ru/flights/schedule/?city=Ростов-на-Дону",
            "https://web.archive.org/web/20210301044819/https://pulkovoairport.ru/flights/schedule/?city=Ростов-на-Дону",
            "https://web.archive.org/web/20201202040310/https://pulkovoairport.ru/flights/schedule/?city=Ростов-на-Дону",
            "https://web.archive.org/web/20200924192031/https://pulkovoairport.ru/flights/schedule/?city=Ростов-на-Дону"
        ],
        "Салехард": [
            "https://web.archive.org/web/20210423021521/https://pulkovoairport.ru/flights/schedule/?city=Салехард",
            "https://web.archive.org/web/20210128114835/https://pulkovoairport.ru/flights/schedule/?city=Салехард",
            "https://web.archive.org/web/20201023213647/https://pulkovoairport.ru/flights/schedule/?city=Салехард",
            "https://web.archive.org/web/20200813171957/https://pulkovoairport.ru/flights/schedule/?city=Салехард"
        ],
        "Самара": [
            "https://web.archive.org/web/20210415165619/https://pulkovoairport.ru/flights/schedule/?city=Самара",
            "https://web.archive.org/web/20210116204922/https://pulkovoairport.ru/flights/schedule/?city=Самара",
            "https://web.archive.org/web/20200929202937/https://pulkovoairport.ru/flights/schedule/?city=Самара"
        ],
        "Саранск": [
            "https://web.archive.org/web/20210421052607/https://pulkovoairport.ru/flights/schedule/?city=Саранск",
            "https://web.archive.org/web/20200925164622/https://pulkovoairport.ru/flights/schedule/?city=Саранск"
        ],
        "Саратов": [
            "https://web.archive.org/web/20210421055419/https://pulkovoairport.ru/flights/schedule/?city=Саратов",
            "https://web.archive.org/web/20210128123958/https://pulkovoairport.ru/flights/schedule/?city=Саратов",
            "https://web.archive.org/web/20201021222651/https://pulkovoairport.ru/flights/schedule/?city=Саратов",
            "https://web.archive.org/web/20200806135513/https://pulkovoairport.ru/flights/schedule/?city=Саратов"
        ],
        "Симферополь": [
            "https://web.archive.org/web/20210421040825/https://pulkovoairport.ru/flights/schedule/?city=Симферополь",
            "https://web.archive.org/web/20210124045851/https://pulkovoairport.ru/flights/schedule/?city=Симферополь",
            "https://web.archive.org/web/20200925152132/https://pulkovoairport.ru/flights/schedule/?city=Симферополь"
        ],
        "Сочи": [
            "https://web.archive.org/web/20210510194643/https://pulkovoairport.ru/flights/schedule/?city=Сочи",
            "https://web.archive.org/web/20210301044511/https://pulkovoairport.ru/flights/schedule/?city=Сочи",
            "https://web.archive.org/web/20201202040011/https://pulkovoairport.ru/flights/schedule/?city=Сочи",
            "https://web.archive.org/web/20200924191550/https://pulkovoairport.ru/flights/schedule/?city=Сочи"
        ],
        "Ставрополь": [
            "https://web.archive.org/web/20210415173224/https://pulkovoairport.ru/flights/schedule/?city=Ставрополь",
            "https://web.archive.org/web/20210116210858/https://pulkovoairport.ru/flights/schedule/?city=Ставрополь",
            "https://web.archive.org/web/20200928183831/https://pulkovoairport.ru/flights/schedule/?city=Ставрополь"
        ],
        "Сургут": [
            "https://web.archive.org/web/20210510175531/https://pulkovoairport.ru/flights/schedule/?city=Сургут",
            "https://web.archive.org/web/20210301031210/https://pulkovoairport.ru/flights/schedule/?city=Сургут",
            "https://web.archive.org/web/20201202021945/https://pulkovoairport.ru/flights/schedule/?city=Сургут",
            "https://web.archive.org/web/20200925151605/https://pulkovoairport.ru/flights/schedule/?city=Сургут"
        ],
        "Сыктывкар": [
            "https://web.archive.org/web/20210415180255/https://pulkovoairport.ru/flights/schedule/?city=Сыктывкар",
            "https://web.archive.org/web/20210116214312/https://pulkovoairport.ru/flights/schedule/?city=Сыктывкар",
            "https://web.archive.org/web/20200929214605/https://pulkovoairport.ru/flights/schedule/?city=Сыктывкар"
        ],
        "Тамбов": [
            "https://web.archive.org/web/20210415181329/https://pulkovoairport.ru/flights/schedule/?city=Тамбов",
            "https://web.archive.org/web/20210116155623/https://pulkovoairport.ru/flights/schedule/?city=Тамбов",
            "https://web.archive.org/web/20201027125134/https://pulkovoairport.ru/flights/schedule/?city=Тамбов"
        ],
        "Томск": [
            "https://web.archive.org/web/20210421053608/https://pulkovoairport.ru/flights/schedule/?city=Томск",
        ],
        "Тюмень": [
            "https://web.archive.org/web/20210415165115/https://pulkovoairport.ru/flights/schedule/?city=Тюмень",
            "https://web.archive.org/web/20210116144305/https://pulkovoairport.ru/flights/schedule/?city=Тюмень",
            "https://web.archive.org/web/20201026040340/https://pulkovoairport.ru/flights/schedule/?city=Тюмень",
            "https://web.archive.org/web/20200813170325/https://pulkovoairport.ru/flights/schedule/?city=Тюмень"
        ],
        "Усинск": [
            "https://web.archive.org/web/20210415160904/https://pulkovoairport.ru/flights/schedule/?city=Усинск",
            "https://web.archive.org/web/20210116200147/https://pulkovoairport.ru/flights/schedule/?city=Усинск"
        ],
        "Уфа": [
            "https://web.archive.org/web/20210421055929/https://pulkovoairport.ru/flights/schedule/?city=Уфа",
            "https://web.archive.org/web/20210128124655/https://pulkovoairport.ru/flights/schedule/?city=Уфа",
            "https://web.archive.org/web/20201021223132/https://pulkovoairport.ru/flights/schedule/?city=Уфа",
            "https://web.archive.org/web/20200806140036/https://pulkovoairport.ru/flights/schedule/?city=Уфа"
        ],
        "Ухта": [
            "https://web.archive.org/web/20210420035145/https://pulkovoairport.ru/flights/schedule/?city=Ухта",
            "https://web.archive.org/web/20210122121747/https://pulkovoairport.ru/flights/schedule/?city=Ухта",
            "https://web.archive.org/web/20200928150543/https://pulkovoairport.ru/flights/schedule/?city=Ухта"
        ],
        "Ханты-Мансийск": [
            "https://web.archive.org/web/20210415174256/https://pulkovoairport.ru/flights/schedule/?city=Ханты-Мансийск",
            "https://web.archive.org/web/20210116211451/https://pulkovoairport.ru/flights/schedule/?city=Ханты-Мансийск",
            "https://web.archive.org/web/20200928184353/https://pulkovoairport.ru/flights/schedule/?city=Ханты-Мансийск"
        ],
        "Чебоксары": [
            "https://web.archive.org/web/20210420052348/https://pulkovoairport.ru/flights/schedule/?city=Чебоксары",
            "https://web.archive.org/web/20210122133529/https://pulkovoairport.ru/flights/schedule/?city=Чебоксары",
            "https://web.archive.org/web/20200928164231/https://pulkovoairport.ru/flights/schedule/?city=Чебоксары"
        ],
        "Челябинск": [
            "https://web.archive.org/web/20210510182040/https://pulkovoairport.ru/flights/schedule/?city=Челябинск",
            "https://web.archive.org/web/20210301033241/https://pulkovoairport.ru/flights/schedule/?city=Челябинск",
            "https://web.archive.org/web/20201202024307/https://pulkovoairport.ru/flights/schedule/?city=Челябинск",
            "https://web.archive.org/web/20200924172517/https://pulkovoairport.ru/flights/schedule/?city=Челябинск"
        ],
        "Череповец": [
            "https://web.archive.org/web/20210415171122/https://pulkovoairport.ru/flights/schedule/?city=Череповец",
            "https://web.archive.org/web/20210116145705/https://pulkovoairport.ru/flights/schedule/?city=Череповец",
            "https://web.archive.org/web/20201026041547/https://pulkovoairport.ru/flights/schedule/?city=Череповец",
            "https://web.archive.org/web/20200810082624/https://pulkovoairport.ru/flights/schedule/?city=Череповец"
        ],
        "Элиста": [
            "https://web.archive.org/web/20210415181604/https://pulkovoairport.ru/flights/schedule/?city=Элиста",
            "https://web.archive.org/web/20210116215501/https://pulkovoairport.ru/flights/schedule/?city=Элиста",
            "https://web.archive.org/web/20200928164956/https://pulkovoairport.ru/flights/schedule/?city=Элиста"
        ],
        "Якутск": [
            "https://web.archive.org/web/20210415173938/https://pulkovoairport.ru/flights/schedule/?city=Якутск",
            "https://web.archive.org/web/20210116211326/https://pulkovoairport.ru/flights/schedule/?city=Якутск",
            "https://web.archive.org/web/20200928184151/https://pulkovoairport.ru/flights/schedule/?city=Якутск"
        ],
        "Ярославль": [
            "https://web.archive.org/web/20210510194940/https://pulkovoairport.ru/flights/schedule/?city=Ярославль",
            "https://web.archive.org/web/20210301044754/https://pulkovoairport.ru/flights/schedule/?city=Ярославль",
            "https://web.archive.org/web/20201202040243/https://pulkovoairport.ru/flights/schedule/?city=Ярославль",
            "https://web.archive.org/web/20200924191952/https://pulkovoairport.ru/flights/schedule/?city=Ярославль"
        ],
    }
    
    all_data = []
    processed_urls = 0
    failed_urls = []
    
    for city, urls in CITY_URLS.items():
        city_data = []
        
        for url in urls:
            # Случайная задержка от 10 до 20 секунд
            delay = random.uniform(10, 20)
            time.sleep(delay)
            
            html = fetch_wayback_snapshot(url)
            
            if html:
                df = parse_flights_table(html, city)
                if df is not None:
                    city_data.append(df)
                    processed_urls += 1
                    print(f"Успешно обработан: {city} | URL: {url}")
                else:
                    failed_urls.append(url)
                    print(f"Не удалось распарсить: {city} | URL: {url}")
            else:
                failed_urls.append(url)
                print(f"Ошибка загрузки: {city} | URL: {url}")
        
        if city_data:
            all_data.append(pd.concat(city_data, ignore_index=True))
    
    if all_data:
        result = pd.concat(all_data, ignore_index=True)
        output_file = 'pulkovo_all_flights.csv'
        result.to_csv(output_file, index=False, encoding='utf-8-sig', sep=';')
        
        # Сохраняем отчет об ошибках
        with open('failed_urls.txt', 'w', encoding='utf-8') as f:
            f.write("\n".join(failed_urls))
        
        print(f"\nИтоговый отчет:")
        print(f"Успешно обработано URL: {processed_urls}")
        print(f"Не удалось обработать URL: {len(failed_urls)}")
        print(f"Всего записей: {len(result)}")
        print(f"Данные сохранены в: {output_file}")
        print(f"Список неудачных URL в: failed_urls.txt")
    else:
        print("Не удалось получить данные ни для одного города")

if __name__ == "__main__":
    print("=== НАЧАЛО РАБОТЫ ===")
    main()