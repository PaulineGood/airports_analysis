import requests
from bs4 import BeautifulSoup
import pandas as pd
from urllib.parse import quote
import time

# Список URL для каждого города (пример)
CITY_URLS = {
    "Москва": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Москва&date=03.04.2025&sevenDays=on",
    "Апатиты": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Апатиты&date=03.04.2025&sevenDays=on",
    "Сочи": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Сочи&date=03.04.2025&sevenDays=on",
    "Архангельск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Архангельск&date=03.04.2025&sevenDays=on",
    "Астрахань": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Астрахань&date=03.04.2025&sevenDays=on",
    "Барнаул": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Барнаул&date=03.04.2025&sevenDays=on",
    "Владикавказ": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Владикавказ&date=03.04.2025&sevenDays=on",
    "Волгоград": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Волгоград&date=03.04.2025&sevenDays=on",
    "Вологда": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Вологда&date=03.04.2025&sevenDays=on",
    "Горно-Алтайск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Горно-Алтайск&date=03.04.2025&sevenDays=on",
    "Грозный": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Грозный&date=03.04.2025&sevenDays=on",
    "Екатеринбург": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Екатеринбург&date=03.04.2025&sevenDays=on",
    "Иваново": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Иваново&date=03.04.2025&sevenDays=on",
    "Ижевск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Ижевск&date=03.04.2025&sevenDays=on",
    "Иркутск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Иркутск&date=03.04.2025&sevenDays=on",
    "Йошкар-Ола": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Йошкар-Ола&date=03.04.2025&sevenDays=on",
    "Казань": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Казань&date=03.04.2025&sevenDays=on",
    "Калининград": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Калининград&date=03.04.2025&sevenDays=on",
    "Калуга": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Калуга&date=03.04.2025&sevenDays=on",
    "Кемерово": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Кемерово&date=03.04.2025&sevenDays=on",
    "Киров": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Киров&date=03.04.2025&sevenDays=on",
    "Кострома": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Кострома&date=03.04.2025&sevenDays=on",
    "Котлас": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Котлас&date=03.04.2025&sevenDays=on",
    "Красноярск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Красноярск&date=03.04.2025&sevenDays=on",
    "Курган": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Курган&date=03.04.2025&sevenDays=on",
    "Магас": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Магас&date=03.04.2025&sevenDays=on",
    "Магнитогорск ": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Магнитогорск &date=03.04.2025&sevenDays=on",
    "Махачкала": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Махачкала&date=03.04.2025&sevenDays=on",
    "Минеральные Воды": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Минеральные Воды&date=03.04.2025&sevenDays=on",
    "Мурманск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Мурманск&date=03.04.2025&sevenDays=on",
    "Надым": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Надым&date=03.04.2025&sevenDays=on",
    "Нарьян-Мар": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Нарьян-Мар&date=03.04.2025&sevenDays=on",
    "Нижневартовск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Нижневартовск&date=03.04.2025&sevenDays=on",
    "Нижнекамск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Нижнекамск&date=03.04.2025&sevenDays=on",
    "Нижний Новгород": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Нижний Новгород&date=03.04.2025&sevenDays=on",
    "Новокузнецк": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Новокузнецк&date=03.04.2025&sevenDays=on",
    "Новосибирск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Новосибирск&date=03.04.2025&sevenDays=on",
    "Новый Уренгой": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Новый Уренгой&date=03.04.2025&sevenDays=on",
    "Норильск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Норильск&date=03.04.2025&sevenDays=on",
    "Ноябрьск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Ноябрьск&date=03.04.2025&sevenDays=on",
    "Омск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Омск&date=03.04.2025&sevenDays=on",
    "Оренбург": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Оренбург&date=03.04.2025&sevenDays=on",
    "Орск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Орск&date=03.04.2025&sevenDays=on",
    "Пенза": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Пенза&date=03.04.2025&sevenDays=on",
    "Пермь": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Пермь&date=03.04.2025&sevenDays=on",
    "Салехард": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Салехард&date=03.04.2025&sevenDays=on",
    "Самара": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Самара&date=03.04.2025&sevenDays=on",
    "Саранск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Саранск&date=03.04.2025&sevenDays=on",
    "Саратов": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Саратов&date=03.04.2025&sevenDays=on",
    "Ставрополь": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Ставрополь&date=03.04.2025&sevenDays=on",
    "Сургут": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Сургут&date=03.04.2025&sevenDays=on",
    "Сыктывкар": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Сыктывкар&date=03.04.2025&sevenDays=on",
    "Тамбов": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Тамбов&date=03.04.2025&sevenDays=on",
    "Тобольск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Тобольск&date=03.04.2025&sevenDays=on",
    "Томск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Томск&date=03.04.2025&sevenDays=on",
    "Тюмень": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Тюмень&date=03.04.2025&sevenDays=on",
    "Ульяновск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Ульяновск&date=03.04.2025&sevenDays=on",
    "Уфа": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Уфа&date=03.04.2025&sevenDays=on",
    "Ухта": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Ухта&date=03.04.2025&sevenDays=on",
    "Ханты-Мансийск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Ханты-Мансийск&date=03.04.2025&sevenDays=on",
    "Чебоксары": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Чебоксары&date=03.04.2025&sevenDays=on",
    "Челябинск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Челябинск&date=03.04.2025&sevenDays=on",
    "Череповец": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Череповец&date=03.04.2025&sevenDays=on",
    "Якутск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Якутск&date=03.04.2025&sevenDays=on",
    "Ярославль": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Ярославль&date=03.04.2025&sevenDays=on",
    "Абу-Даби": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Абу-Даби&date=03.04.2025&sevenDays=on",
    "Алматы": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Алматы&date=03.04.2025&sevenDays=on",
    "Анталья": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Анталья&date=03.04.2025&sevenDays=on",
    "Астана": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Астана&date=03.04.2025&sevenDays=on",
    "Баку": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Баку&date=03.04.2025&sevenDays=on",
    "Бангкок": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Бангкок&date=03.04.2025&sevenDays=on",
    "Батуми": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Батуми&date=03.04.2025&sevenDays=on",
    "Белград": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Белград&date=03.04.2025&sevenDays=on",
    "Бишкек": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Бишкек&date=03.04.2025&sevenDays=on",
    "Брест": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Брест&date=03.04.2025&sevenDays=on",
    "Бухара": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Бухара&date=03.04.2025&sevenDays=on",
    "Гомель": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Гомель&date=03.04.2025&sevenDays=on",
    "Дубай": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Дубай&date=03.04.2025&sevenDays=on",
    "Душанбе": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Душанбе&date=03.04.2025&sevenDays=on",
    "Ереван": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Ереван&date=03.04.2025&sevenDays=on",
    "Карши": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Карши&date=03.04.2025&sevenDays=on",
    "Коломбо": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Коломбо&date=03.04.2025&sevenDays=on",
    "Кутаиси": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Кутаиси&date=03.04.2025&sevenDays=on",
    "Минск": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Минск&date=03.04.2025&sevenDays=on",
    "Монастир": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Монастир&date=03.04.2025&sevenDays=on",
    "Наманган": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Наманган&date=03.04.2025&sevenDays=on",
    "Ош": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Ош&date=03.04.2025&sevenDays=on",
    "Пекин": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Пекин&date=03.04.2025&sevenDays=on",
    "Пхукет": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Пхукет&date=03.04.2025&sevenDays=on",
    "Самарканд": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Самарканд&date=03.04.2025&sevenDays=on",
    "Стамбул": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Стамбул&date=03.04.2025&sevenDays=on",
    "Ташкент": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Ташкент&date=03.04.2025&sevenDays=on",
    "Тбилиси": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Тбилиси&date=03.04.2025&sevenDays=on",
    "Тегеран": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Тегеран&date=03.04.2025&sevenDays=on",
    "Термез": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Термез&date=03.04.2025&sevenDays=on",
    "Тунис": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Тунис&date=03.04.2025&sevenDays=on",
    "Ургенч": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Ургенч&date=03.04.2025&sevenDays=on",
    "Фергана": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Фергана&date=03.04.2025&sevenDays=on",
    "Худжанд": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Худжанд&date=03.04.2025&sevenDays=on",
    "Хургада": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Хургада&date=03.04.2025&sevenDays=on",
    "Чэнду": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Чэнду&date=03.04.2025&sevenDays=on",
    "Шанхай": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Шанхай&date=03.04.2025&sevenDays=on",
    "Шарм-эль-Шейх": "https://pulkovoairport.ru/passengers/destinations/flight_schedule/?city=Шарм-эль-Шейх&date=03.04.2025&sevenDays=on",
}

def parse_schedule(url, city_name):
    """Парсит расписание с учетом всех особенностей верстки"""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=20)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Находим таблицу прилетов
        table = soup.find('table', {'class': 'uk-table table-shedule ths_arrival active'})
        if not table:
            print(f"Таблица не найдена для города {city_name}")
            return None
        
        # Получаем заголовки
        headers = []
        header_row = table.find('tr', {'class': 'city__form__title'})
        if header_row:
            headers = [th.get_text(strip=True) for th in header_row.find_all('th')]
        else:
            headers = ["Рейс", "Авиакомпания", "Дата", "Время", "Дни недели", "Самолет"]
        
        # Парсим строки (пропускаем заголовок и строку-разделитель)
        flights = []
        rows = table.find_all('tr')[2:]  # Пропускаем первые 2 строки
        
        for row in rows:
            cols = row.find_all('td')
            if len(cols) < len(headers):
                continue
                
            # Обрабатываем дни недели - берем только selected
            days_cell = cols[4]  # 5-й столбец - дни недели
            selected_days = days_cell.find_all('span', {'class': 'timetable_weekday selected'})
            if not selected_days:
                continue  # Пропускаем если нет выбранных дней
                
            days_str = ", ".join([day.get_text(strip=True) for day in selected_days])
            
            flight = {
                'Город': city_name,
                'Рейс': cols[0].get_text(strip=True),
                'Авиакомпания': cols[1].get_text(strip=True),
                'Дата': cols[2].get_text(strip=True),
                'Время': cols[3].get_text(strip=True),
                'Дни недели': days_str,  # Только выбранные дни
                'Самолет': cols[5].get_text(strip=True) if len(cols) > 5 else ''
            }
            flights.append(flight)
        
        return pd.DataFrame(flights)
        
    except Exception as e:
        print(f"Ошибка при парсинге {city_name}: {str(e)}")
        return None

def main():
    all_schedules = []
    
    for city_name, url in CITY_URLS.items():
        print(f"Обрабатываем город: {city_name}")
        start_time = time.time()
        
        city_df = parse_schedule(url, city_name)
        if city_df is not None and not city_df.empty:
            all_schedules.append(city_df)
            print(f"Добавлено {len(city_df)} рейсов. Время обработки: {time.time()-start_time:.1f} сек")
        else:
            print(f"Не удалось получить данные для {city_name}")
        
        time.sleep(1.5)  # Пауза между запросами
    
    if all_schedules:
        result_df = pd.concat(all_schedules, ignore_index=True)
        
        # Очистка данных
        result_df = result_df.drop_duplicates()
        result_df = result_df[result_df['Рейс'].str.strip() != '']
        
        # Сохранение
        output_file = 'pulkovo_filtered_schedule.csv'
        result_df.to_csv(output_file, 
                        index=False, 
                        encoding='utf-8-sig', 
                        sep=';')
        
        print(f"\nРезультат сохранен в {output_file}")
        print(f"Всего записей: {len(result_df)}")
        print("Структура данных:")
        print(result_df.info())
    else:
        print("Не удалось получить ни одного расписания")

if __name__ == "__main__":
    print("=== ПАРСИНГ РАСПИСАНИЯ ПУЛКОВО ===")
    main()