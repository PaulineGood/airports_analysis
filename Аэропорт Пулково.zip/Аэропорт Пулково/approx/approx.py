import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import matplotlib.dates as mdates
from matplotlib.collections import LineCollection
import numpy as np
from matplotlib.lines import Line2D

HOLIDAYS = {'01-01', '01-07', '02-23', '03-08', '05-01', '05-09', '06-12', '11-04'}

def parse_date(date_str):
    if pd.isna(date_str):
        return pd.NaT
    try:
        return pd.to_datetime(date_str, dayfirst=True, errors='coerce')
    except:
        return pd.NaT

def load_csv_data(path):
    df = pd.read_csv(path, sep=';', encoding='utf-8')
    df['Дата'] = df['Дата'].apply(parse_date)
    return df.dropna(subset=['Дата'])

def load_excel_data(path):
    df = pd.read_excel(path)
    records = []
    for idx, row in df.iterrows():
        day_month = row.iloc[0]
        for year in df.columns[1:]:
            val = row[year]
            if pd.notna(val):
                try:
                    date_str = f"{day_month}.{int(year)}"
                    date = pd.to_datetime(date_str, format="%d.%m.%Y")
                    records.append({'Дата': date, 'count': val, 'year': int(year)})
                except Exception as e:
                    pass
    df_res = pd.DataFrame(records)
    df_res = df_res.sort_values(by=['Дата', 'year']).reset_index(drop=True)
    return df_res

csv_df = load_csv_data('current_flights.csv')

if 'count' not in csv_df.columns:
    csv_df = csv_df.groupby('Дата').size().reset_index(name='count')
else:
    csv_df = csv_df.groupby('Дата')['count'].sum().reset_index()

excel_df = load_excel_data('real_flights.xlsx')
excel_df['year'] = excel_df['Дата'].dt.year

start_date = min(csv_df['Дата'].min(), excel_df['Дата'].min())
end_date = max(csv_df['Дата'].max(), excel_df['Дата'].max())
full_range = pd.date_range(start=start_date, end=end_date)

df_all = pd.DataFrame({'Дата': full_range})
df_all = df_all.merge(csv_df, on='Дата', how='left')
df_all['weekday'] = df_all['Дата'].dt.weekday
df_all['month'] = df_all['Дата'].dt.month
df_all['date_str'] = df_all['Дата'].dt.strftime('%m-%d')

weekday_avg = csv_df.copy()
weekday_avg['weekday'] = weekday_avg['Дата'].dt.weekday
weekday_avg = weekday_avg.groupby('weekday')['count'].mean()

def fill_missing(row):
    if not pd.isna(row['count']):
        row['is_real'] = True
        return row

    date = row['Дата']
    year = date.year
    month = row['month']
    weekday = row['weekday']
    date_str = row['date_str']

    base = {2023: 300, 2024: 250, 2025: 250}.get(year, 150)
    season = 1.3 if month in [6, 7, 8] else (0.8 if month in [1, 2] else 1.0)
    weekday_factor = weekday_avg.get(weekday, 140) / 140
    holiday = 0.7 if date_str in HOLIDAYS else 1.0

    row['count'] = base * season * weekday_factor * holiday
    row['is_real'] = False
    return row

df_all = df_all.apply(fill_missing, axis=1)
df_all['smoothing'] = df_all['count'].rolling(window=14, center=True, min_periods=1).mean()

fig, ax = plt.subplots(figsize=(18, 6))

dates = df_all['Дата'].values
values = df_all['smoothing'].values
is_real = df_all['is_real'].values

points = np.array([mdates.date2num(dates), values]).T.reshape(-1, 1, 2)
segments = np.concatenate([points[:-1], points[1:]], axis=1)
colors = ['#1f77b4' if is_real[i] and is_real[i+1] else '#ffae42' for i in range(len(is_real)-1)]
lc = LineCollection(segments, colors=colors, linewidth=2)
ax.add_collection(lc)

years = sorted(excel_df['year'].unique())
for y in years:
    subset = excel_df[excel_df['year'] == y].copy()
    subset = subset.sort_values('Дата')
    subset['smoothing'] = subset['count'].rolling(window=14, center=True, min_periods=1).mean()
    ax.plot(subset['Дата'], subset['smoothing'], label=f'Excel данные {y}', color='black', linewidth=2)

ax.set_xlim(dates[0], dates[-1])
ax.set_ylim(min(np.nanmin(values), excel_df['count'].min()), max(np.nanmax(values), excel_df['count'].max()))
ax.set_title('Рейсы в Санкт-Петербург (2023–2025)')
ax.set_xlabel('Дата')
ax.set_ylabel('Количество рейсов (сглаженное)')

ax.xaxis.set_major_locator(mdates.MonthLocator(bymonth=(1,4,7,10)))
ax.xaxis.set_major_formatter(mdates.DateFormatter('%b %Y'))
ax.xaxis.set_minor_locator(mdates.MonthLocator())
plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')

ax.grid(True)

# --- Добавляем вертикальные линии на 1 января каждого года ---
for y in years:
    jan_1 = pd.Timestamp(year=y, month=1, day=1)
    ax.axvline(jan_1, color='gray', linestyle='--', linewidth=1)

# --- Легенда с единой записью для Excel ---
legend_lines = [
    Line2D([0], [0], color='#1f77b4', lw=2),
    Line2D([0], [0], color='#ffae42', lw=2),
    Line2D([0], [0], color='black', lw=2)
]
legend_labels = ['CSV: реальные', 'CSV: аппроксимация', 'Excel данные (2023–2025)']

ax.legend(legend_lines, legend_labels)

plt.tight_layout()
plt.savefig('combined_flight_graph.png', dpi=300)
plt.show()
