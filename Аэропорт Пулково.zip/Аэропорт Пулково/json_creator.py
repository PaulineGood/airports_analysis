import csv
import json
from datetime import datetime

def parse_date(date_str):
    """
    Пробуем распарсить дату в разных форматах,
    например '03.04.2025' или '30 сентября 2020'
    """
    for fmt in ("%d.%m.%Y", "%d %B %Y", "%d %b %Y"):
        try:
            return datetime.strptime(date_str, fmt).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None  # Если не получилось распарсить

def normalize_days(days_str):
    """
    Преобразуем 'Пн, Вт, Ср' -> ['пн', 'вт', 'ср']
    """
    if not days_str:
        return None
    days = [d.strip().lower() for d in days_str.split(',')]
    return days if days else None

def process_row(row):
    """
    Преобразует строку csv в нужный словарь с пропуском отсутствующих ключей
    """
    result = {}

    # Дата расписания
    date_parsed = parse_date(row.get('Дата', '').strip())
    if date_parsed:
        result["Дата расписания"] = date_parsed

    # Время отправления
    time_depart = row.get('Время', '').strip()
    if time_depart:
        result["Отправление"] = time_depart

    # Прибытие - в csv нет, пропускаем

    # Дни полетов
    days = normalize_days(row.get('Дни недели', '').strip())
    if days:
        result["Дни полетов"] = days

    # Период - нет в csv, пропускаем

    # Авиакомпания
    airline = row.get('Авиакомпания', '').strip()
    if airline:
        result["Авиакомпания"] = airline

    # Номер рейса
    flight_num = row.get('Рейс', '').strip()
    if flight_num:
        result["Номер рейса"] = flight_num

    # Тип судна
    aircraft = row.get('Самолет', '').strip()
    if aircraft:
        result["Тип судна"] = aircraft

    # Аэропорт - нет, пропускаем

    return result if result else None

def csv_to_list(csv_filename):
    data = []
    with open(csv_filename, encoding='utf-8') as f:
        reader = csv.DictReader(f, delimiter=';')
        for row in reader:
            processed = process_row(row)
            if processed:
                data.append(processed)
    return data

def save_json(data, json_filename):
    with open(json_filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

# Основная часть

file1 = 'covid.csv'  # замени на имя первого файла
file2 = 'current_flights.csv'  # замени на имя второго файла
output_file = 'SPB_comb.json'  # имя итогового JSON

data1 = csv_to_list(file1)
data2 = csv_to_list(file2)

combined_data = data1 + data2

save_json(combined_data, output_file)

print(f"Обработано {len(combined_data)} записей. Сохранено в {output_file}")
